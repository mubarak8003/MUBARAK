"use client";

import { useOnlineStatus } from '@/hooks/use-online-status';
import { WifiOff } from 'lucide-react';

export default function OfflineIndicator() {
  const isOnline = useOnlineStatus();

  if (isOnline) {
    return null;
  }

  return (
    <div className="fixed inset-0 z-[101] flex items-center justify-center bg-background/80 backdrop-blur-sm">
        <div className="flex flex-col items-center gap-4 rounded-lg border bg-background p-8 text-center shadow-lg">
            <WifiOff className="h-16 w-16 text-destructive" />
            <h2 className="text-2xl font-bold">OOPS! NO INTERNET</h2>
            <p className="text-muted-foreground">Please check your network connection.</p>
        </div>
    </div>
  );
}
