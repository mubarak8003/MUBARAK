
"use client";

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { RotateCw, ArrowUp, ArrowDown, ArrowLeft, ArrowRight } from 'lucide-react';
import { cn } from '@/lib/utils';

const GRID_SIZE = 20;
const INITIAL_SNAKE = [{ x: 10, y: 10 }];
const INITIAL_FOOD = { x: 15, y: 15 };
const INITIAL_DIRECTION = { x: 0, y: -1 }; // Moving UP initially
const GAME_SPEED = 200; // ms

type Coordinate = {
  x: number;
  y: number;
};

const SnakeGame = () => {
  const [snake, setSnake] = useState<Coordinate[]>(INITIAL_SNAKE);
  const [food, setFood] = useState<Coordinate>(INITIAL_FOOD);
  const [direction, setDirection] = useState<Coordinate>(INITIAL_DIRECTION);
  const [isGameOver, setIsGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [isGameRunning, setIsGameRunning] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const gameContainerRef = useRef<HTMLDivElement>(null);


  useEffect(() => {
    try {
      const storedHighScore = localStorage.getItem('snakeGameHighScore');
      if (storedHighScore) {
        setHighScore(parseInt(storedHighScore, 10));
      }
    } catch (e) {
      console.error("Could not read high score from local storage", e);
    }
  }, []);

  const handleDirectionChange = (newDirection: Coordinate) => {
      setDirection(currentDirection => {
          // Prevent the snake from reversing on itself
          if (newDirection.x !== 0 && currentDirection.x === 0) return newDirection;
          if (newDirection.y !== 0 && currentDirection.y === 0) return newDirection;
          return currentDirection;
      });
  };

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    e.preventDefault();
    switch (e.key) {
      case 'ArrowUp':
        handleDirectionChange({ x: 0, y: -1 });
        break;
      case 'ArrowDown':
        handleDirectionChange({ x: 0, y: 1 });
        break;
      case 'ArrowLeft':
        handleDirectionChange({ x: -1, y: 0 });
        break;
      case 'ArrowRight':
        handleDirectionChange({ x: 1, y: 0 });
        break;
    }
  }, []);

  useEffect(() => {
    if(isGameRunning) {
      document.addEventListener('keydown', handleKeyDown);
    }
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown, isGameRunning]);

  const generateFood = (snakeBody: Coordinate[]): Coordinate => {
    let newFood: Coordinate;
    do {
      newFood = {
        x: Math.floor(Math.random() * GRID_SIZE),
        y: Math.floor(Math.random() * GRID_SIZE),
      };
    } while (snakeBody.some(segment => segment.x === newFood.x && segment.y === newFood.y));
    return newFood;
  };
  
    const resetGame = useCallback((resume = false) => {
    if (!resume) {
      if (score > highScore) {
        setHighScore(score);
        try {
          localStorage.setItem('snakeGameHighScore', score.toString());
        } catch (e) {
          console.error("Could not save high score to local storage", e);
        }
      }
      setSnake(INITIAL_SNAKE);
      setFood(INITIAL_FOOD);
      setDirection(INITIAL_DIRECTION);
      setScore(0);
    }
    setIsGameOver(false);
    setIsGameRunning(true);
    setIsPaused(false);
  }, [score, highScore]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (!entry.isIntersecting && isGameRunning && !isGameOver) {
          setIsPaused(true);
          setIsGameRunning(false);
        }
      },
      { threshold: 0.1 }
    );

    const currentRef = gameContainerRef.current;
    if (currentRef) {
      observer.observe(currentRef);
    }

    return () => {
      if (currentRef) {
        observer.unobserve(currentRef);
      }
    };
  }, [isGameRunning, isGameOver]);
  
  useEffect(() => {
    if (!isGameRunning || isGameOver) return;

    const gameInterval = setInterval(() => {
      setSnake(prevSnake => {
        const newSnake = [...prevSnake];
        const head = { ...newSnake[0] };
        head.x += direction.x;
        head.y += direction.y;

        // Wall collision
        if (head.x < 0 || head.x >= GRID_SIZE || head.y < 0 || head.y >= GRID_SIZE) {
          setIsGameOver(true);
          setIsGameRunning(false);
          return prevSnake;
        }

        // Self collision
        for (let i = 1; i < newSnake.length; i++) {
          if (head.x === newSnake[i].x && head.y === newSnake[i].y) {
            setIsGameOver(true);
            setIsGameRunning(false);
            return prevSnake;
          }
        }

        newSnake.unshift(head);

        // Food collision
        if (head.x === food.x && head.y === food.y) {
          setScore(s => s + 1);
          setFood(generateFood(newSnake));
        } else {
          newSnake.pop();
        }

        return newSnake;
      });
    }, GAME_SPEED);

    return () => clearInterval(gameInterval);
  }, [snake, direction, food, isGameRunning, isGameOver]);

  const displayedSnake = isGameRunning || isPaused || isGameOver ? snake : INITIAL_SNAKE;
  const displayedFood = isGameRunning || isPaused || isGameOver ? food : INITIAL_FOOD;

  const getEyeClasses = () => {
    if (direction.y === -1) { // Up
      return { eye1: "top-1/4 left-1/4", eye2: "top-1/4 right-1/4" };
    }
    if (direction.y === 1) { // Down
      return { eye1: "bottom-1/4 left-1/4", eye2: "bottom-1/4 right-1/4" };
    }
    if (direction.x === -1) { // Left
      return { eye1: "top-1/4 left-1/4", eye2: "bottom-1/4 left-1/4" };
    }
    // Right
    return { eye1: "top-1/4 right-1/4", eye2: "bottom-1/4 right-1/4" };
  };

  const eyeClasses = getEyeClasses();

  return (
    <Card ref={gameContainerRef} className="w-full max-w-md mx-auto shadow-lg">
      <CardHeader className="p-4">
        <div className="flex justify-between items-center">
            <CardTitle className="text-xl">Snake Game</CardTitle>
            <div className="text-right">
                <p className="text-sm text-muted-foreground">High Score: {highScore}</p>
                <p className="text-lg font-bold">Score: {score}</p>
            </div>
        </div>
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <div className="relative aspect-square w-full bg-muted rounded-lg overflow-hidden border">
           {(!isGameRunning || isGameOver) && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-background/80 z-10">
                <h3 className="text-2xl font-bold mb-1">{isGameOver ? "Game Over!" : (isPaused ? "Game Paused" : "Ready to Play?")}</h3>
                {isGameOver && <p className="text-muted-foreground mb-4">Your final score is {score}.</p>}
                <Button onClick={() => resetGame(isPaused && !isGameOver)}>{isPaused && !isGameOver ? "Resume" : "Play Again"}</Button>
            </div>
          )}
             <div className="grid h-full w-full" style={{ gridTemplateColumns: `repeat(${GRID_SIZE}, 1fr)` }}>
              {Array.from({ length: GRID_SIZE * GRID_SIZE }).map((_, i) => (
                <div key={i} className="aspect-square bg-muted" />
              ))}
              {displayedSnake.map((segment, index) => (
                <div
                  key={index}
                  className={cn(
                    'absolute bg-green-500',
                     index === 0 ? 'rounded-t-sm' : 'rounded-sm'
                  )}
                  style={{
                    left: `${(segment.x / GRID_SIZE) * 100}%`,
                    top: `${(segment.y / GRID_SIZE) * 100}%`,
                    width: `${100 / GRID_SIZE}%`,
                    height: `${100 / GRID_SIZE}%`,
                    backgroundColor: index === 0 ? '#2E7D32' : '#4CAF50',
                  }}
                >
                {index === 0 && (
                    <div className="relative w-full h-full">
                        <div className={cn("absolute w-1/4 h-1/4 bg-white rounded-full", eyeClasses.eye1)}></div>
                        <div className={cn("absolute w-1/4 h-1/4 bg-white rounded-full", eyeClasses.eye2)}></div>
                    </div>
                )}
                </div>
              ))}
              <div
                className="absolute rounded-full bg-red-600"
                style={{
                    left: `${(displayedFood.x / GRID_SIZE) * 100}%`,
                    top: `${(displayedFood.y / GRID_SIZE) * 100}%`,
                    width: `${100 / GRID_SIZE}%`,
                    height: `${100 / GRID_SIZE}%`,
                }}
              />
            </div>
        </div>
        <div className="flex flex-col items-center justify-center mt-4 space-y-2">
            <Button variant="outline" size="icon" className="h-12 w-12" onClick={() => handleDirectionChange({x: 0, y: -1})} aria-label="Up">
                <ArrowUp />
            </Button>
            <div className="flex space-x-2">
                <Button variant="outline" size="icon" className="h-12 w-12" onClick={() => handleDirectionChange({x: -1, y: 0})} aria-label="Left">
                    <ArrowLeft />
                </Button>
                <Button variant="outline" size="icon" className="h-12 w-12" onClick={() => handleDirectionChange({x: 0, y: 1})} aria-label="Down">
                    <ArrowDown />
                </Button>
                <Button variant="outline" size="icon" className="h-12 w-12" onClick={() => handleDirectionChange({x: 1, y: 0})} aria-label="Right">
                    <ArrowRight />
                </Button>
            </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default SnakeGame;
