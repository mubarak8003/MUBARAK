
import Link from 'next/link';

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="container mx-auto px-4 py-8 max-w-3xl">
        <h1 className="text-3xl font-bold mb-6">Privacy Policy for tacalculator.com</h1>
        <p className="mb-4">Last updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>

        <div className="space-y-6 text-muted-foreground">
          <p>
            Welcome to tacalculator.com ("we", "our", "us"). We are committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website. Please read this privacy policy carefully. If you do not agree with the terms of this privacy policy, please do not access the site.
          </p>

          <div className="space-y-4">
            <h2 className="text-2xl font-semibold text-foreground">Information We Collect</h2>
            <p>
              We may collect information about you in a variety of ways. The information we may collect on the Site includes:
            </p>
            <h3 className="text-xl font-semibold text-foreground">Personal Data</h3>
            <p>
              We do not collect personally identifiable information, such as your name, shipping address, email address, or telephone number.
            </p>

            <h3 className="text-xl font-semibold text-foreground">Data You Provide to the Calculators</h3>
             <p>
              Our calculators require you to input financial data such as your account balance, risk tolerance, and trade details. This information is processed in your browser and stored locally on your device using your browser's `localStorage` functionality. This data is not transmitted to our servers and is used solely to provide the functionality of the calculators and persist your sessions. Since this data is stored on your own device, you have full control over it and can clear it at any time by clearing your browser's cache and data.
            </p>

            <h3 className="text-xl font-semibold text-foreground">Derivative Data</h3>
            <p>
              Our servers may automatically collect information when you access the Site, such as your IP address, your browser type, your operating system, your access times, and the pages you have viewed directly before and after accessing the Site. This is standard for most websites and is used for analytics and security purposes.
            </p>
          </div>

          <div className="space-y-4">
            <h2 className="text-2xl font-semibold text-foreground">Use of Your Information</h2>
            <p>
              Having accurate information permits us to offer a seamless experience. Specifically, we may use information collected about you via the Site to:
            </p>
            <ul className="list-disc list-inside space-y-2">
              <li>Compile anonymous statistical data and analysis for use internally or with third parties.</li>
              <li>Improve the efficiency and operation of the Site.</li>
              <li>Monitor and analyze usage and trends to improve your experience with the Site.</li>
              <li>Deliver and manage advertising.</li>
            </ul>
          </div>

          <div className="space-y-4">
            <h2 className="text-2xl font-semibold text-foreground">Cookies and Web Beacons</h2>
            <p>
              We may use cookies, web beacons, tracking pixels, and other tracking technologies on the Site to help customize the Site and improve your experience. When you access the Site, your personal information is not collected through the use of tracking technology. Most browsers are set to accept cookies by default. You can remove or reject cookies, but be aware that such action could affect the availability and functionality of the Site.
            </p>
          </div>

          <div className="space-y-4">
            <h2 className="text-2xl font-semibold text-foreground">Third-Party Websites and Advertising</h2>
            <p>
              We may use third-party advertising companies to serve ads when you visit the Site. These companies may use information about your visits to the Site and other websites that are contained in web cookies in order to provide advertisements about goods and services of interest to you.
            </p>
            <p>
              Specifically, we use Google AdSense and Google Analytics. Google's use of advertising cookies enables it and its partners to serve ads to your users based on their visit to your sites and/or other sites on the Internet. You may opt out of personalized advertising by visiting <a href="https://www.google.com/settings/ads" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Ads Settings</a>.
            </p>
          </div>
          
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold text-foreground">Security of Your Information</h2>
            <p>
                We use administrative, technical, and physical security measures to help protect your information. While we have taken reasonable steps to secure the information you provide to us, please be aware that despite our efforts, no security measures are perfect or impenetrable, and no method of data transmission can be guaranteed against any interception or other type of misuse.
            </p>
          </div>

          <div className="space-y-4">
            <h2 className="text-2xl font-semibold text-foreground">Policy for Children</h2>
            <p>
                We do not knowingly solicit information from or market to children under the age of 13. If you become aware of any data we have collected from children under age 13, please contact us using the contact information provided below.
            </p>
          </div>

          <div className="space-y-4">
            <h2 className="text-2xl font-semibold text-foreground">Changes to This Privacy Policy</h2>
            <p>
              We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page. You are advised to review this Privacy Policy periodically for any changes.
            </p>
          </div>

          <div className="space-y-4">
            <h2 className="text-2xl font-semibold text-foreground">Contact Us</h2>
            <p>
              If you have questions or comments about this Privacy Policy, please contact us at: <a href="mailto:support@tacalculator.com" className="text-primary hover:underline">support@tacalculator.com</a>
            </p>
          </div>
        </div>
        <div className="mt-8 text-center">
            <Link href="/" className="text-primary hover:underline">
                &larr; Back to Calculators
            </Link>
        </div>
      </div>
    </div>
  );
}
