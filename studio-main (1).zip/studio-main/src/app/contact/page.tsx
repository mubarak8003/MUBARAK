
import Link from 'next/link';
import { Mail, MessageCircle, Heart, DollarSign } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <h1 className="text-3xl font-bold mb-2 text-center">Contact Us</h1>
        <p className="text-muted-foreground text-center mb-8">
          Have questions, feedback, or need help with our tools? We're here to help.
        </p>

        <div className="grid gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-xl">
                <Mail className="h-5 w-5 text-primary" /> Email Support
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                For general inquiries, bug reports, or partnership opportunities, please reach out to us via email:
              </p>
              <a 
                href="mailto:support@tacalculator.com" 
                className="text-xl font-bold text-primary hover:underline block text-center p-4 border rounded-lg bg-muted/30"
              >
                support@tacalculator.com
              </a>
              <p className="text-[10px] text-muted-foreground mt-4 text-center italic">
                We typically respond within 24-48 hours.
              </p>
            </CardContent>
          </Card>

          <Card className="border-primary/20 bg-primary/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-xl">
                <Heart className="h-5 w-5 text-red-500 fill-red-500" /> Support Our Project
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Tacalculator.com is a free project built to help traders maintain discipline. If our tools have helped you, consider supporting us to keep the servers running.
              </p>
              <div className="flex flex-wrap gap-3 justify-center">
                <Button variant="outline" asChild className="bg-background">
                  <Link href="https://www.paypal.com/ncp/payment/KV667MC9XD5J6" target="_blank" rel="noopener noreferrer">
                    <DollarSign className="mr-2 h-4 w-4 text-blue-600" /> PayPal
                  </Link>
                </Button>
                <Button variant="outline" asChild>
                  <Link href="https://www.paypal.com/paypalme/mubarak8003" target="_blank" rel="noopener noreferrer">
                    <MessageCircle className="mr-2 h-4 w-4" /> PayPal.me
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="mt-12 text-center space-y-4">
          <p className="text-xs text-muted-foreground">
            Our mission is to provide the best free risk management tools for traders worldwide. Thank you for being part of our community.
          </p>
          <Link href="/" className="text-primary hover:underline font-bold block">
            &larr; Back to Calculators
          </Link>
        </div>
      </div>
    </div>
  );
}
