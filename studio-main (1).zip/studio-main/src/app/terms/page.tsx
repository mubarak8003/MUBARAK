import Link from 'next/link';

export default function TermsOfService() {
  const lastUpdated = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="container mx-auto px-4 py-8 max-w-3xl">
        <h1 className="text-3xl font-bold mb-6">Terms of Service</h1>
        <p className="mb-4">Last updated: {lastUpdated}</p>

        <div className="space-y-6 text-muted-foreground">
          <section className="space-y-4">
            <h2 className="text-2xl font-semibold text-foreground">1. Acceptance of Terms</h2>
            <p>
              By accessing and using tacalculator.com ("the Website"), you agree to be bound by these Terms of Service and all applicable laws and regulations. If you do not agree with any of these terms, you are prohibited from using or accessing this site.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-semibold text-foreground">2. Disclaimer & No Financial Advice</h2>
            <p className="font-bold text-foreground">
              IMPORTANT: The calculators and information provided on tacalculator.com are for educational and informational purposes only.
            </p>
            <p>
              We are not financial advisors, brokers, or tax professionals. Trading financial markets (Stocks, Forex, Crypto) involves significant risk of loss and is not suitable for every investor. You should never trade with money you cannot afford to lose.
            </p>
            <p>
              While we strive for mathematical accuracy, we make no guarantees regarding the results produced by our calculators. Use of these tools is at your own risk.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-semibold text-foreground">3. Use License</h2>
            <p>
              Permission is granted to use the tools on tacalculator.com for personal, non-commercial use. You may not:
            </p>
            <ul className="list-disc list-inside space-y-2">
              <li>Modify or copy the source code of the calculators.</li>
              <li>Use the materials for any commercial purpose without prior written consent.</li>
              <li>Attempt to decompile or reverse engineer any software contained on the Website.</li>
            </ul>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-semibold text-foreground">4. Limitation of Liability</h2>
            <p>
              In no event shall tacalculator.com or its owners be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the tools on the Website, even if we have been notified orally or in writing of the possibility of such damage.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-semibold text-foreground">5. External Links</h2>
            <p>
              Tacalculator.com has not reviewed all of the sites linked to its website and is not responsible for the contents of any such linked site. The inclusion of any link does not imply endorsement by tacalculator.com. Use of any such linked website is at the user's own risk.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-semibold text-foreground">6. Modifications</h2>
            <p>
              We may revise these terms of service at any time without notice. By using this website, you are agreeing to be bound by the then-current version of these Terms of Service.
            </p>
          </section>
        </div>

        <div className="mt-8 text-center">
          <Link href="/" className="text-primary hover:underline font-bold">
            &larr; Back to Calculators
          </Link>
        </div>
      </div>
    </div>
  );
}
