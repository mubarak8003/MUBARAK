
"use client";

import { useState, useEffect, useMemo, useRef } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { 
  Loader2, Globe, ChevronRight, BarChart3, Settings2, RotateCw, ArrowUpRight, ArrowDownRight, Sparkles, 
  Percent, Trophy, PartyPopper, Briefcase, RefreshCcw, Plus, Trash2, TrendingUp, TrendingDown, Wallet, 
  ArrowUpCircle, ArrowDownCircle, Info, BookOpen, Newspaper, Search, Check, ChevronsUpDown, CandlestickChart, 
  LineChart, Brain, ShieldCheck, Edit3, Clock, Download, Upload, Calculator, XCircle
} from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ThemeToggle } from "@/components/theme-toggle";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Area, AreaChart, ResponsiveContainer, XAxis, YAxis, Tooltip as ChartTooltip, BarChart as ReBarChart, Bar, Cell } from "recharts";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import Link from "next/link";
import { analyzeMarket, type MarketAnalysisOutput } from "@/ai/flows/market-analysis-flow";
import confetti from "canvas-confetti";

const ADVISOR_STATE_KEY = "tradeAdvisorSession_v210";
const STOCK_SL_STATE_KEY = "stockRiskCalculatorState_v210";
const FOREX_LOT_STATE_KEY = "forexLotCalculatorState_v210";
const PORTFOLIO_STATE_KEY = "portfolioManagerState_v210";
const WEALTH_STATE_KEY = "wealthManagerState_v210";
const DIFF_WALLET_STATE_KEY = "diffWalletBalanceState_v210";
const TURNOVER_STATE_KEY = "totalTurnoverState_v210";
const PREFERENCES_KEY = "userPreferences_v210";

type Currency = "INR" | "USD" | "EUR" | "GBP";

const CURRENCY_SYMBOLS: Record<Currency, string> = {
  INR: "₹",
  USD: "$",
  EUR: "€",
  GBP: "£"
};

const PSYCHOLOGICAL_QUOTES = [
  "Trade your setup, not your emotions.",
  "The market rewards patience, not panic.",
  "One emotional trade can destroy weeks of discipline.",
  "Losses are part of trading, revenge is optional.",
  "Professional traders follow rules even when feelings scream otherwise.",
  "If your emotions are driving, your account is surviving.",
  "Calm mind, clear chart, better decision.",
  "Discipline is the real edge in trading.",
  "Don't chase candles, chase consistency.",
  "A good trader controls risk before chasing profit."
];

const FOREX_170 = Array.from(new Set([
  "EUR USD", "GBP USD", "USD JPY", "AUD USD", "USD CAD", "USD CHF", "NZD USD", "EUR GBP", "EUR JPY", "GBP JPY",
  "AUD JPY", "EUR AUD", "GBP AUD", "GBP CAD", "NZD JPY", "CAD JPY", "AUD CAD", "EUR NZD", "GBP NZD",
  "AUD NZD", "CHF JPY", "AUD CHF", "GBP CHF", "EUR CHF", "NZD CAD", "NZD CHF", "CAD CHF", "USD SGD", "USD HKD",
  "USD ZAR", "USD TRY", "USD MXN", "USD CNH", "EUR SGD", "EUR HKD", "EUR TRY", "GBP SGD", "GBP HKD", "AUD SGD",
  "AUD HKD", "SGD JPY", "HKD JPY", "USD SEK", "USD NOK", "USD DKK", "EUR SEK", "EUR NOK", "GBP SEK", "GBP NOK",
  "CAD SGD", "CHF SGD", "EUR ZAR", "GBP ZAR", "AUD ZAR", "NZD ZAR", "EUR MXN", "GBP MXN", "USD PLN", "EUR PLN",
  "USD HUF", "EUR HUF", "USD CZK", "EUR CZK", "USD ILS", "USD THB", "USD MYR", "USD PHP", "USD TWD", "USD KRW",
  "AUD BRL", "EUR BRL", "USD BRL", "USD RUB", "EUR RUB", "AUD CLP", "USD CLP", "USD COP", "USD PEN", "USD ARS",
  "USD INR", "EUR INR", "GBP INR", "JPY INR", "SGD INR", "AUD INR", "CAD INR", "NZD INR", "CHF INR", "ZAR INR",
  "AED USD", "SAR USD", "QAR USD", "KWD USD", "BHD USD", "OMR USD", "USD AED", "USD SAR", "USD QAR", "USD KWD",
  "USD BHD", "USD OMR", "SGD MYR", "SGD PHP", "SGD IDR", "SGD THB", "SGD KRW", "SGD TWD", "SGD VND", "AUD MYR", 
  "CAD MYR", "CHF MYR", "EUR MYR", "GBP MYR", "JPY MYR", "NZD MYR", "AUD PHP", "CAD PHP", "CHF PHP", "EUR PHP", 
  "GBP PHP", "JPY PHP", "NZD PHP", "AUD IDR", "CAD IDR", "CHF IDR", "EUR IDR", "GBP IDR", "JPY IDR", "NZD IDR", 
  "AUD THB", "CAD THB", "CHF THB", "EUR THB", "GBP THB", "JPY THB", "NZD THB", "AUD VND", "CAD VND", "CHF VND", 
  "EUR VND", "GBP VND", "JPY VND", "NZD VND", "EUR KES", "NGN USD", "GHS USD", "ZAR JPY", "TRY JPY", "MXN JPY", 
  "BRL JPY", "INR JPY", "USD JOD", "USD LKR", "USD MUR", "USD PKR", "EUR BHD", "EUR OMR", "EUR SAR", "CAD HKD",
  "CHF HKD", "NZD HKD", "CAD SEK", "CHF SEK", "CAD NOK", "CHF NOK", "CAD DKK", "CHF DKK", "NZD SEK", "NZD NOK"
])).slice(0, 170);

const OTHER_30 = Array.from(new Set([
  "BTC USD", "ETH USD", "SOL USD", "XRP USD", "ADA USD", "DOT USD", "DOGE USD", "AVAX USD", "LINK USD", "MATIC USD",
  "LTC USD", "BCH USD", "SHIB USD", "UNI USD", "XLM USD", "XAU USD", "XAG USD", "XPT USD", "XPD USD", "XTI USD",
  "XBR USD", "NATGAS USD", "US30", "NAS100", "SPX500", "GER40", "UK100", "FRA40", "HK50", "JPN225"
]));

const ALL_ASSETS = [
  ...FOREX_170.map(p => ({ pair: p, type: "FOREX", price: p.includes("JPY") || p.includes("HUF") || p.includes("KRW") || p.includes("INR") ? 150.00 : 1.1000 })),
  ...OTHER_30.map(p => ({ pair: p, type: "OTHER", price: p.includes("BTC") ? 68000 : p.includes("ETH") ? 3500 : p.includes("XAU") ? 2100 : 100 }))
].map(s => ({
  ...s,
  marketStrength: ["Strong", "Building", "Moderate", "Weak", "Ranging", "Developing"][Math.floor(Math.random() * 6)]
}));

function FloatingClock() {
  const [time, setTime] = useState<Date | null>(null);
  const [position, setPosition] = useState({ x: 20, y: 80 });
  const [isDragging, setIsDragging] = useState(false);
  const [rel, setRel] = useState({ x: 0, y: 0 });

  useEffect(() => {
    setTime(new Date());
    const interval = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  const onStart = (e: React.MouseEvent | React.TouchEvent) => {
    setIsDragging(true);
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    setRel({
      x: clientX - position.x,
      y: clientY - position.y
    });
  };

  useEffect(() => {
    const onMove = (e: MouseEvent | TouchEvent) => {
      if (!isDragging) return;
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
      
      const newX = Math.max(0, Math.min(window.innerWidth - 120, clientX - rel.x));
      const newY = Math.max(60, Math.min(window.innerHeight - 50, clientY - rel.y));
      
      setPosition({ x: newX, y: newY });
    };

    const onEnd = () => {
      setIsDragging(false);
    };

    if (isDragging) {
      window.addEventListener('mousemove', onMove);
      window.addEventListener('mouseup', onEnd);
      window.addEventListener('touchmove', onMove, { passive: false });
      window.addEventListener('touchend', onEnd);
    }

    return () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onEnd);
      window.removeEventListener('touchmove', onMove);
      window.removeEventListener('touchend', onEnd);
    };
  }, [isDragging, rel]);

  if (!time) return null;

  return (
    <div
      style={{
        left: `${position.x}px`,
        top: `${position.y}px`,
        touchAction: 'none'
      }}
      onMouseDown={onStart}
      onTouchStart={onStart}
      className={cn(
        "fixed z-[100] cursor-move select-none",
        "bg-background/90 backdrop-blur-md border-2 border-primary/40 rounded-xl px-3 py-1.5",
        "flex items-center gap-2 shadow-lg shadow-primary/20 transition-transform",
        isDragging && "scale-110 opacity-90 shadow-primary/40"
      )}
    >
      <div className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse" />
      <span className="font-mono text-sm font-black text-primary tabular-nums tracking-wider">
        {time.toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })}
      </span>
    </div>
  );
}

function TradingSignals() {
  const [signals, setSignals] = useState(ALL_ASSETS);
  const [selectedAnalysisPair, setSelectedAnalysisPair] = useState("EUR USD");
  const [analysis, setAnalysis] = useState<MarketAnalysisOutput | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [open, setOpen] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const interval = setInterval(() => {
      setSignals(prev => prev.map(s => ({
        ...s,
        price: Number((s.price + (Math.random() - 0.5) * (s.price * 0.0001)).toFixed(5))
      })));
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const handleRunAnalysis = async () => {
    setIsAnalyzing(true);
    const target = signals.find(s => s.pair === selectedAnalysisPair);
    try {
      const result = await analyzeMarket({ pair: selectedAnalysisPair, currentPrice: target?.price || 0 });
      setAnalysis(result);
    } catch (e) {
      toast({ title: "Analysis Delayed", description: "HFT servers retrying...", variant: "default" });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const filteredSignals = useMemo(() => {
    return signals.filter(s => s.pair.toLowerCase().includes(searchTerm.toLowerCase()));
  }, [signals, searchTerm]);

  return (
    <Card className="w-full shadow-xl border-2 overflow-hidden bg-card border-x-0 sm:border-x-2 rounded-2xl">
      <CardHeader className="p-4 border-b bg-muted/20">
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
            <span className="font-black uppercase tracking-widest text-[10px] text-muted-foreground">Live Scalp Feed (200 Assets)</span>
          </div>
          <span className="text-[9px] font-black text-primary uppercase">Institutional AI Active</span>
        </div>
        <div className="flex gap-2">
          <Popover open={open} onOpenChange={setOpen}>
            <PopoverTrigger asChild>
              <Button variant="outline" className="h-12 flex-1 justify-between font-black uppercase border-2 bg-background rounded-xl">
                {selectedAnalysisPair}
                <ArrowDownRight className="ml-2 h-4 w-4 shrink-0 opacity-50" />
              </Button>
            </PopoverTrigger>
            <PopoverContent 
              className="w-[300px] p-0" 
              align="start"
              onOpenAutoFocus={(e) => e.preventDefault()}
            >
              <div className="p-2 border-b bg-muted/20">
                <div className="relative">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input 
                    placeholder="Search asset..." 
                    className="pl-8 h-9 text-xs font-bold uppercase border-2 focus-visible:ring-primary" 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>
              <ScrollArea className="h-[300px]">
                <div className="p-1">
                  {filteredSignals.map(s => (
                    <div
                      key={`signal-${s.pair}`}
                      onClick={() => {
                        setSelectedAnalysisPair(s.pair);
                        setOpen(false);
                        setSearchTerm("");
                      }}
                      className={cn(
                        "flex items-center justify-between px-3 py-2 text-xs font-bold uppercase cursor-pointer rounded-lg hover:bg-primary hover:text-white transition-colors",
                        selectedAnalysisPair === s.pair && "bg-primary/10 text-primary"
                      )}
                    >
                      <span>{s.pair}</span>
                      {selectedAnalysisPair === s.pair && <Check className="h-4 w-4" />}
                    </div>
                  ))}
                  {filteredSignals.length === 0 && (
                    <div className="p-4 text-center text-xs font-bold text-muted-foreground uppercase italic">No asset found</div>
                  )}
                </div>
              </ScrollArea>
            </PopoverContent>
          </Popover>
          <Button onClick={handleRunAnalysis} disabled={isAnalyzing} className="h-12 px-6 font-black uppercase text-xs gap-2 border-b-4 border-primary/50 active:translate-y-1 transition-all rounded-xl">
            {isAnalyzing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />} ANALYZE
          </Button>
        </div>
        {analysis && (
          <div className="mt-4 grid grid-cols-2 gap-3 animate-in fade-in slide-in-from-top-4 duration-500">
             <div className={cn("border-2 rounded-xl p-4 text-center shadow-inner", analysis.signal === 'BUY' ? "bg-green-500/10 border-green-500/50" : "bg-red-500/10 border-red-500/50")}>
               <div className="text-[9px] font-black text-muted-foreground uppercase mb-1">Signal</div>
               <div className={cn("text-2xl font-black italic uppercase tracking-tighter", analysis.signal === 'BUY' ? "text-green-600" : "text-red-600")}>{analysis.signal}</div>
             </div>
             <div className="bg-background border-2 rounded-xl p-4 text-center shadow-inner">
               <div className="text-[9px] font-black text-muted-foreground uppercase mb-1">Market Status</div>
               <div className="text-[11px] font-black text-primary uppercase leading-none">{analysis.status}</div>
             </div>
             <div className="col-span-2 bg-muted/30 p-3 rounded-lg border border-dashed border-muted-foreground/30">
               <p className="text-[11px] italic font-bold uppercase leading-snug">{analysis.insight}</p>
             </div>
          </div>
        )}
      </CardHeader>
      <CardContent className="p-0 max-h-[500px] overflow-y-auto no-scrollbar">
        {signals.map((s, idx) => (
          <div key={`feed-${s.pair}-${idx}`} className="flex justify-between items-center p-4 border-b hover:bg-muted/10 transition-colors">
            <div><h3 className="font-black uppercase tracking-tight">{s.pair}</h3><div className="text-[10px] font-mono font-bold text-muted-foreground">{s.price.toFixed(5)}</div></div>
            <div className="text-right"><div className="text-[9px] font-black text-muted-foreground uppercase mb-1">Strength</div><div className="text-[10px] font-black text-primary uppercase bg-primary/10 px-2 py-0.5 rounded border border-primary/20">{s.marketStrength}</div></div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

function WealthManager({ currency }: { currency: Currency }) {
  const [transactions, setTransactions] = useState<{ id: string; type: 'income' | 'expense'; category: string; amount: string }[]>([]);
  const [category, setCategory] = useState("");
  const [amount, setAmount] = useState("");
  const [type, setType] = useState<'income' | 'expense'>('income');
  const [isInitialized, setIsInitialized] = useState(false);
  
  const [walletBalance, setWalletBalance] = useState(0);
  const [manualWalletVal, setManualWalletVal] = useState("");
  const [walletMode, setWalletMode] = useState<'add' | 'withdraw'>('withdraw');
  const [totalTurnover, setTotalTurnover] = useState(0);
  
  const { toast } = useToast();

  const [diffBase, setDiffBase] = useState("1000");
  const [diffP1, setDiffP1] = useState("85");
  const [diffP2, setDiffP2] = useState("88");

  useEffect(() => {
    const savedWealth = localStorage.getItem(WEALTH_STATE_KEY);
    if (savedWealth) {
      try { setTransactions(JSON.parse(savedWealth)); } catch (e) {}
    }
    
    const savedWallet = localStorage.getItem(DIFF_WALLET_STATE_KEY);
    if (savedWallet) {
      try { setWalletBalance(parseFloat(savedWallet) || 0); } catch (e) {}
    }

    const savedTurnover = localStorage.getItem(TURNOVER_STATE_KEY);
    if (savedTurnover) {
      try { setTotalTurnover(parseFloat(savedTurnover) || 0); } catch (e) {}
    }
    
    setIsInitialized(true);
  }, []);

  useEffect(() => {
    if (isInitialized) {
      localStorage.setItem(WEALTH_STATE_KEY, JSON.stringify(transactions));
      localStorage.setItem(DIFF_WALLET_STATE_KEY, walletBalance.toString());
      localStorage.setItem(TURNOVER_STATE_KEY, totalTurnover.toString());
    }
  }, [transactions, walletBalance, totalTurnover, isInitialized]);

  const addTransaction = () => {
    if (!category || !amount) {
      toast({ title: "Error", description: "Fill all fields.", variant: "destructive" });
      return;
    }
    const newTx = {
      id: Math.random().toString(36).substr(2, 9),
      type,
      category: category.toUpperCase(),
      amount
    };
    setTransactions([...transactions, newTx]);
    setCategory("");
    setAmount("");
    toast({ title: "Success", description: "Entry added to Wealth Manager." });
  };

  const removeTransaction = (id: string) => {
    setTransactions(transactions.filter(t => t.id !== id));
  };

  const totals = useMemo(() => {
    let inc = 0;
    let exp = 0;
    transactions.forEach(t => {
      const val = parseFloat(t.amount) || 0;
      if (t.type === 'income') inc += val;
      else exp += val;
    });
    return { inc, exp, net: inc - exp };
  }, [transactions]);

  const diffResults = useMemo(() => {
    const base = parseFloat(diffBase) || 0;
    const p1 = parseFloat(diffP1) || 0;
    const p2 = parseFloat(diffP2) || 0;
    const v1 = (base * p1) / 100;
    const v2 = (base * p2) / 100;
    const diff = Math.abs(v2 - v1);
    return { v1, v2, diff };
  }, [diffBase, diffP1, diffP2]);

  const handleWalletDeposit = () => {
    setWalletBalance(prev => prev + diffResults.diff);
    setTotalTurnover(prev => prev + (parseFloat(diffBase) || 0));
    toast({ 
      title: "Deposit Successful", 
      description: `${diffResults.diff.toFixed(2)} added to your Diff Wallet and Turnover updated.` 
    });
  };

  const handleManualWalletAction = () => {
    const val = parseFloat(manualWalletVal) || 0;
    if (val <= 0) {
      toast({ title: "Invalid Amount", description: "Please enter a value greater than 0.", variant: "destructive" });
      return;
    }

    if (walletMode === 'withdraw') {
      if (val > walletBalance) {
        toast({ title: "Insufficient Balance", description: "You don't have enough funds to withdraw.", variant: "destructive" });
        return;
      }
      setWalletBalance(prev => prev - val);
      toast({ title: "Withdraw Successful", description: `${val.toFixed(2)} withdrawn from wallet.` });
    } else {
      setWalletBalance(prev => prev + val);
      toast({ title: "Deposit Successful", description: `${val.toFixed(2)} added to wallet.` });
    }
    setManualWalletVal("");
  };

  const clearTurnover = () => {
    setTotalTurnover(0);
    toast({ title: "Turnover Cleared", description: "Cumulative turnover has been reset to zero." });
  };

  const format = (v: number) => v.toLocaleString(currency === 'INR' ? 'en-IN' : 'en-US', { style: 'currency', currency });

  return (
    <div className="space-y-6">
      <Accordion type="single" collapsible className="border-none space-y-4" defaultValue="diff-calc">
        <AccordionItem value="diff-calc" className="border-2 rounded-2xl bg-card shadow-sm overflow-hidden border-x-0 sm:border-x-2 border-primary/30">
          <AccordionTrigger className="px-4 py-3 hover:no-underline hover:bg-primary/5">
            <div className="flex items-center gap-2 font-black uppercase text-[11px] tracking-widest text-primary mx-auto">
              <Calculator className="h-4 w-4" /> PERCENTAGE DIFF CALCULATOR
            </div>
          </AccordionTrigger>
          <AccordionContent className="p-4 pt-2 space-y-6">
            
            <div className="bg-primary/5 p-4 rounded-xl border-2 border-primary/20 mb-4 space-y-2">
              <div className="flex justify-between items-start w-full">
                <p className="text-[9px] font-black text-muted-foreground uppercase tracking-widest pt-1">DIFF WALLET BALANCE</p>
                <div className="relative flex items-center bg-background border-2 rounded-lg pr-1 shadow-sm">
                   <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={() => setWalletMode(prev => prev === 'withdraw' ? 'add' : 'withdraw')}
                    className="h-8 w-8 text-muted-foreground hover:text-primary hover:bg-transparent"
                   >
                     {walletMode === 'withdraw' ? <Upload className="h-4 w-4" /> : <Download className="h-4 w-4" />}
                   </Button>
                   <Input 
                    type="number" 
                    inputMode="decimal"
                    placeholder="0.00"
                    value={manualWalletVal}
                    onChange={e => setManualWalletVal(e.target.value)}
                    className="h-8 w-16 text-[11px] font-black border-none focus-visible:ring-0 p-1 text-center"
                   />
                   <Button 
                    onClick={handleManualWalletAction}
                    size="icon" 
                    variant="ghost" 
                    className={cn("h-6 w-6 rounded-md ml-1", walletMode === 'withdraw' ? "text-red-500 hover:bg-red-500/10" : "text-green-500 hover:bg-green-500/10")}
                   >
                     <Check className="h-4 w-4" />
                   </Button>
                 </div>
              </div>
              <p className="text-3xl font-black text-green-500 italic tracking-tight break-all">
                {format(walletBalance)}
              </p>
              
              <div className="flex justify-between items-center pt-2 border-t border-primary/10">
                <div className="flex flex-col">
                  <p className="text-[8px] font-black text-muted-foreground uppercase tracking-widest">CUMULATIVE TURNOVER</p>
                  <p className="text-sm font-black text-foreground tabular-nums">{format(totalTurnover)}</p>
                </div>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={clearTurnover}
                  className="h-7 px-2 text-[8px] font-black uppercase text-red-500 hover:bg-red-500/10"
                >
                  <XCircle className="h-3 w-3 mr-1" /> Clear
                </Button>
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-1.5">
                <Label className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">Base Amount</Label>
                <Input 
                  type="number" 
                  inputMode="decimal"
                  value={diffBase} 
                  onChange={e => setDiffBase(e.target.value)} 
                  className="h-12 font-black border-2 bg-background rounded-xl border-primary/20" 
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">Percentage One (%)</Label>
                  <Input 
                    type="number" 
                    inputMode="decimal"
                    value={diffP1} 
                    onChange={e => setDiffP1(e.target.value)} 
                    className="h-12 font-black border-2 bg-background rounded-xl border-primary/20" 
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">Percentage Two (%)</Label>
                  <Input 
                    type="number" 
                    inputMode="decimal"
                    value={diffP2} 
                    onChange={e => setDiffP2(e.target.value)} 
                    className="h-12 font-black border-2 bg-background rounded-xl border-primary/20" 
                  />
                </div>
              </div>
            </div>

            <div className="bg-primary/5 p-6 rounded-2xl border-2 border-dashed border-primary/20 space-y-4 text-center">
              <div className="grid grid-cols-2 gap-4 text-center">
                <div className="space-y-1">
                  <p className="text-[9px] font-black text-muted-foreground uppercase">{diffP1}% Value</p>
                  <p className="text-lg font-black text-foreground">{diffResults.v1.toFixed(2)}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-[9px] font-black text-muted-foreground uppercase">{diffP2}% Value</p>
                  <p className="text-lg font-black text-foreground">{diffResults.v2.toFixed(2)}</p>
                </div>
              </div>
              <Separator className="bg-primary/20" />
              <div className="space-y-4">
                <p className="text-[10px] font-black text-primary uppercase tracking-widest">DIFFERENCE</p>
                <div className="flex flex-col items-center gap-3">
                  <p className="text-5xl font-black italic tracking-tighter text-primary">{diffResults.diff.toFixed(2)}</p>
                  <Button 
                    onClick={handleWalletDeposit}
                    className="h-12 px-6 font-black uppercase text-xs gap-2 rounded-xl border-b-4 border-primary/50 bg-primary hover:bg-primary/90 shadow-md"
                  >
                    <Download className="h-4 w-4" /> DEPOSIT TO WALLET
                  </Button>
                </div>

                <p className="text-[8px] font-bold text-muted-foreground uppercase italic mt-4">
                  Islie {diffP1}% aur {diffP2}% ke beech {diffResults.diff.toFixed(2)} ka difference hai ({diffBase} me).
                </p>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="manage" className="border-2 rounded-2xl bg-card shadow-sm overflow-hidden border-x-0 sm:border-x-2">
          <AccordionTrigger className="px-4 py-3 hover:no-underline hover:bg-muted/5">
            <div className="flex items-center gap-2 font-black uppercase text-[11px] tracking-widest text-foreground/80 mx-auto">
              <Plus className="h-4 w-4" /> MANAGE WEALTH
            </div>
          </AccordionTrigger>
          <AccordionContent className="p-4 pt-2 space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">Type</Label>
                <Select value={type} onValueChange={(v: any) => setType(v)}>
                  <SelectTrigger className="h-12 font-black uppercase border-2 bg-background rounded-xl">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="income" className="font-bold">INCOME (+)</SelectItem>
                    <SelectItem value="expense" className="font-bold">EXPENSE (-)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">Name/Source</Label>
                <Input 
                  placeholder="SALARY / RENT" 
                  value={category} 
                  onChange={e => setCategory(e.target.value)} 
                  className="h-12 font-black uppercase border-2 bg-background rounded-xl" 
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">Amount</Label>
                <Input 
                  type="number" 
                  inputMode="decimal"
                  placeholder="0.00" 
                  value={amount} 
                  onChange={e => setAmount(e.target.value)} 
                  className="h-12 font-black border-2 bg-background rounded-xl" 
                />
              </div>
              <div className="flex items-end">
                <Button onClick={addTransaction} className="w-full h-12 font-black uppercase border-b-4 border-green-700 shadow-lg bg-green-600 hover:bg-green-700 rounded-xl">
                  ADD ENTRY
                </Button>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>

      <div className="grid grid-cols-2 gap-4 px-2">
        <Card className="border-2 rounded-2xl p-6 text-center space-y-2 bg-card shadow-md">
          <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">TOTAL INCOME</p>
          <div className="flex items-center justify-center gap-2 text-xl font-black text-green-600">
            <ArrowUpCircle className="h-5 w-5" /> {format(totals.inc)}
          </div>
        </Card>
        <Card className="border-2 rounded-2xl p-6 text-center space-y-2 bg-card shadow-md">
          <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">TOTAL EXPENSES</p>
          <div className="flex items-center justify-center gap-2 text-xl font-black text-red-600">
            <ArrowDownCircle className="h-5 w-5" /> {format(totals.exp)}
          </div>
        </Card>
      </div>

      <Card className={cn("border-2 rounded-3xl p-8 text-center shadow-lg mx-2", totals.net >= 0 ? "bg-green-500/5 border-green-500/30" : "bg-red-500/5 border-red-500/30")}>
        <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest mb-3">NET SAVINGS (CAPITAL TO GROW)</p>
        <div className={cn("text-4xl font-black italic uppercase tracking-tighter", totals.net >= 0 ? "text-green-600" : "text-red-600")}>
          {format(totals.net)}
        </div>
      </Card>

      <Card className="border-2 rounded-3xl overflow-hidden bg-card shadow-xl border-x-0 sm:border-x-2">
        <Table>
          <TableHeader className="bg-muted/30">
            <TableRow className="h-10">
              <TableHead className="text-[9px] font-black uppercase px-4">TRANSACTION</TableHead>
              <TableHead className="text-[9px] font-black uppercase text-right px-4">AMOUNT</TableHead>
              <TableHead className="w-10 px-2"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {transactions.map(t => (
              <TableRow key={`tx-${t.id}`} className="hover:bg-muted/10 h-14">
                <TableCell className="px-4">
                  <div className="flex flex-col">
                    <span className="font-black text-[11px] uppercase">{t.category}</span>
                    <span className={cn("text-[8px] font-bold uppercase", t.type === 'income' ? "text-green-500" : "text-red-500")}>
                      {t.type}
                    </span>
                  </div>
                </TableCell>
                <TableCell className={cn("text-right font-black text-[11px] px-4", t.type === 'income' ? "text-green-600" : "text-red-600")}>
                  {t.type === 'income' ? "+" : "-"}{format(parseFloat(t.amount))}
                </TableCell>
                <TableCell className="px-2">
                  <Button variant="ghost" size="icon" onClick={() => removeTransaction(t.id)} className="h-7 w-7 text-destructive hover:bg-destructive/10 rounded-full">
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
            {transactions.length === 0 && (
              <TableRow>
                <TableCell colSpan={3} className="text-center py-10 text-[9px] font-bold text-muted-foreground uppercase italic tracking-widest">No income or expense tracked yet</TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}

function PortfolioManager({ currency }: { currency: Currency }) {
  const [items, setItems] = useState<{ id: string; ticker: string; buyPrice: string; currentPrice: string; qty: string }[]>([]);
  const [ticker, setTicker] = useState("");
  const [buyPrice, setBuyPrice] = useState("");
  const [currentPrice, setCurrentPrice] = useState("");
  const [qty, setQty] = useState("1");
  const [isInitialized, setIsInitialized] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const saved = localStorage.getItem(PORTFOLIO_STATE_KEY);
    if (saved) {
      try { setItems(JSON.parse(saved)); } catch (e) {}
    }
    setIsInitialized(true);
  }, []);

  useEffect(() => {
    if (isInitialized) {
      localStorage.setItem(PORTFOLIO_STATE_KEY, JSON.stringify(items));
    }
  }, [items, isInitialized]);

  const addItem = () => {
    if (!ticker || !buyPrice || !currentPrice || !qty) {
      toast({ title: "Error", description: "Please fill all fields.", variant: "destructive" });
      return;
    }
    const newItem = {
      id: Math.random().toString(36).substr(2, 9),
      ticker: ticker.toUpperCase(),
      buyPrice,
      currentPrice,
      qty
    };
    setItems([...items, newItem]);
    setTicker("");
    setBuyPrice("");
    setCurrentPrice("");
    setQty("1");
    toast({ title: "Success", description: `${ticker.toUpperCase()} added to portfolio.` });
  };

  const removeItem = (id: string) => {
    setItems(items.filter(i => i.id !== id));
  };

  const updateItem = (id: string, field: 'currentPrice' | 'qty' | 'buyPrice', value: string) => {
    setItems(prev => prev.map(item => item.id === id ? { ...item, [field]: value } : item));
  };

  const format = (v: number) => v.toLocaleString(currency === 'INR' ? 'en-IN' : 'en-US', { style: 'currency', currency });

  const stats = useMemo(() => {
    let totalInvested = 0;
    let totalCurrentValue = 0;
    items.forEach(i => {
      const q = parseFloat(i.qty) || 0;
      totalInvested += (parseFloat(i.buyPrice) || 0) * q;
      totalCurrentValue += (parseFloat(i.currentPrice) || 0) * q;
    });
    const totalPL = totalCurrentValue - totalInvested;
    const totalPLPer = totalInvested > 0 ? (totalPL / totalInvested) * 100 : 0;
    return { totalInvested, totalCurrentValue, totalPL, totalPLPer };
  }, [items]);

  return (
    <div className="space-y-6">
      <Accordion type="single" collapsible className="border-none">
        <AccordionItem value="manage" className="border-2 rounded-2xl bg-card shadow-sm overflow-hidden border-x-0 sm:border-x-2">
          <AccordionTrigger className="px-4 py-3 hover:no-underline hover:bg-muted/5">
            <div className="flex items-center gap-2 font-black uppercase text-[11px] tracking-widest text-foreground/80 mx-auto">
              <Briefcase className="h-4 w-4" /> MANAGE PORTFOLIO
            </div>
          </AccordionTrigger>
          <AccordionContent className="p-4 pt-2 space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              <div className="space-y-1">
                <Label className="text-[10px] font-black uppercase text-muted-foreground">Ticker</Label>
                <Input placeholder="BTC" value={ticker} onChange={e => setTicker(e.target.value)} className="h-10 font-bold uppercase border-2 bg-background" />
              </div>
              <div className="space-y-1">
                <Label className="text-[10px] font-black uppercase text-muted-foreground">Qty</Label>
                <Input type="number" inputMode="decimal" value={qty} onChange={e => setQty(e.target.value)} className="h-10 font-bold border-2 bg-background" />
              </div>
              <div className="space-y-1">
                <Label className="text-[10px] font-black uppercase text-muted-foreground">Buy Price</Label>
                <Input type="number" inputMode="decimal" value={buyPrice} onChange={e => setBuyPrice(e.target.value)} className="h-10 font-bold border-2 bg-background" />
              </div>
              <div className="space-y-1">
                <Label className="text-[10px] font-black uppercase text-muted-foreground">Current Price</Label>
                <Input type="number" inputMode="decimal" value={currentPrice} onChange={e => setCurrentPrice(e.target.value)} className="h-10 font-bold border-2 bg-background" />
              </div>
            </div>
            <Button onClick={addItem} className="w-full h-12 font-black uppercase gap-2 border-b-4 border-primary/50 shadow-lg text-white bg-green-600 hover:bg-green-700">
              <Plus className="h-4 w-4" /> ADD TO PORTFOLIO
            </Button>
          </AccordionContent>
        </AccordionItem>
      </Accordion>

      <div className="grid grid-cols-2 gap-4 px-2">
        <Card className="border-2 rounded-2xl p-6 text-center space-y-2 bg-card shadow-md">
          <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">TOTAL INVESTED</p>
          <p className="text-xl font-black">{format(stats.totalInvested)}</p>
        </Card>
        <Card className="border-2 rounded-2xl p-6 text-center space-y-2 bg-card shadow-md">
          <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">CURRENT VALUE</p>
          <p className="text-xl font-black text-green-600">{format(stats.totalCurrentValue)}</p>
        </Card>
      </div>

      <Card className={cn("border-2 rounded-3xl p-8 text-center shadow-lg relative overflow-hidden mx-2", stats.totalPL >= 0 ? "bg-green-500/5 border-green-500/30" : "bg-red-500/5 border-red-500/30")}>
        <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest mb-3">TOTAL PROFIT/LOSS</p>
        <div className={cn("text-4xl font-black italic uppercase tracking-tighter flex items-center justify-center gap-2", stats.totalPL >= 0 ? "text-green-600" : "text-red-600")}>
          {stats.totalPL >= 0 ? <TrendingUp className="h-8 w-8" /> : <TrendingDown className="h-8 w-8" />}
          {stats.totalPL >= 0 ? "+" : ""}{format(stats.totalPL)}
        </div>
        <p className={cn("text-base font-black mt-1", stats.totalPL >= 0 ? "text-green-600" : "text-red-600")}>({stats.totalPLPer.toFixed(2)}%)</p>
      </Card>

      <div className="border-2 rounded-3xl overflow-hidden bg-card shadow-xl border-x-0 sm:border-x-2">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader className="bg-muted/30">
              <TableRow className="h-10">
                <TableHead className="text-[9px] font-black uppercase min-w-[50px] px-2">ASSET</TableHead>
                <TableHead className="text-[9px] font-black uppercase text-center min-w-[40px] px-1">QTY</TableHead>
                <TableHead className="text-[9px] font-black uppercase text-center min-w-[60px] px-1">BUY</TableHead>
                <TableHead className="text-[9px] font-black uppercase text-center min-w-[60px] px-1">CURRENT</TableHead>
                <TableHead className="text-[9px] font-black uppercase text-right min-w-[70px] px-2">P/L & %</TableHead>
                <TableHead className="w-8 px-1"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map(i => {
                const b = parseFloat(i.buyPrice) || 0;
                const c = parseFloat(i.currentPrice) || 0;
                const q = parseFloat(i.qty) || 0;
                const pl = (c - b) * q;
                const plPer = b > 0 ? ((c - b) / b) * 100 : 0;
                return (
                  <TableRow key={`port-${i.id}`} className="hover:bg-muted/10 group h-12">
                    <TableCell className="font-black text-[11px] uppercase p-2">{i.ticker}</TableCell>
                    <TableCell className="p-1">
                      <div className="flex items-center justify-center border-b-2 border-dashed border-muted-foreground/20 hover:border-primary transition-colors max-w-[40px] mx-auto">
                        <Input 
                          type="number" 
                          inputMode="decimal"
                          value={i.qty} 
                          onChange={e => updateItem(i.id, 'qty', e.target.value)} 
                          className="h-7 w-full font-bold text-center text-[11px] border-none bg-transparent focus-visible:ring-0 p-0"
                        />
                      </div>
                    </TableCell>
                    <TableCell className="p-1">
                      <div className="flex items-center justify-center border-b-2 border-dashed border-muted-foreground/20 hover:border-primary transition-colors max-w-[60px] mx-auto">
                        <Input 
                          type="number" 
                          inputMode="decimal"
                          value={i.buyPrice} 
                          onChange={e => updateItem(i.id, 'buyPrice', e.target.value)} 
                          className="h-7 w-full font-black text-[11px] text-center border-none bg-transparent focus-visible:ring-0 p-0"
                        />
                      </div>
                    </TableCell>
                    <TableCell className="p-1">
                      <div className="flex items-center justify-center border-b-2 border-dashed border-muted-foreground/20 hover:border-primary transition-colors max-w-[60px] mx-auto">
                        <Input 
                          type="number" 
                          inputMode="decimal"
                          value={i.currentPrice} 
                          onChange={e => updateItem(i.id, 'currentPrice', e.target.value)} 
                          className="h-7 w-full font-black text-[11px] text-center border-none bg-transparent focus-visible:ring-0 p-0"
                        />
                      </div>
                    </TableCell>
                    <TableCell className="text-right p-2">
                       <div className={cn("text-[10px] font-black uppercase tabular-nums", pl >= 0 ? "text-green-600" : "text-red-600")}>
                         {pl >= 0 ? "+" : ""}{format(pl)}
                       </div>
                       <div className={cn("text-[8px] font-bold uppercase", pl >= 0 ? "text-green-600" : "text-red-600")}>
                         ({plPer.toFixed(2)}%)
                       </div>
                    </TableCell>
                    <TableCell className="p-1">
                      <Button variant="ghost" size="icon" onClick={() => removeItem(i.id)} className="h-7 w-7 text-destructive hover:bg-destructive/10 rounded-full">
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
              {items.length === 0 && (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8 text-[9px] font-bold text-muted-foreground uppercase italic tracking-widest">Portfolio is empty</TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}

type BalanceHistoryItem = {
  id: number;
  balance: number;
  tradeAmount?: number;
  isWin?: boolean;
  pnl?: number;
};

function TradeAdvisorCalculator({ currency }: { currency: Currency }) {
  const [initialAmount, setInitialAmount] = useState("1000");
  const [noOfTrades, setNoOfTrades] = useState("100");
  const [targetProfitPer, setTargetProfitPer] = useState("1");
  const [payoutVal, setPayoutVal] = useState("85");
  const [payoutMode, setPayoutMode] = useState<"payout" | "rr" >("payout");
  const [rrVal, setRrVal] = useState("2");
  const [brokerageVal, setBrokerageVal] = useState("0");
  const [brokerageMode, setBrokerageMode] = useState<"amount" | "percent">("amount");
  const [totalBrokerageAccumulated, setTotalBrokerageAccumulated] = useState(0);
  
  const [sessionInitial, setSessionInitial] = useState(1000);
  const [currentBalance, setCurrentBalance] = useState(1000);
  const [balanceHistory, setBalanceHistory] = useState<BalanceHistoryItem[]>([{ id: 0, balance: 1000 }]);
  const [wins, setWins] = useState(0);
  const [losses, setLosses] = useState(0);
  const [consecutiveLosses, setConsecutiveLosses] = useState(0);
  const [disciplineQuote, setDisciplineQuote] = useState<string | null>(null);
  const [autoPL, setAutoPL] = useState(true);
  const [winRateGuideVal, setWinRateGuideVal] = useState("50");
  const [lastTradePLAmount, setLastTradePLAmount] = useState("");
  const [isInitialized, setIsInitialized] = useState(false);
  const [isSessionComplete, setIsSessionComplete] = useState(false);
  const [graphStyle, setGraphStyle] = useState<"line" | "candle">("line");
  const [userRules, setUserRules] = useState("");

  const { toast } = useToast();
  const chartScrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const saved = localStorage.getItem(ADVISOR_STATE_KEY);
    if (saved) {
      try {
        const p = JSON.parse(saved);
        setInitialAmount(String(p.initialAmount || "1000"));
        setNoOfTrades(String(p.noOfTrades || "100"));
        setTargetProfitPer(String(p.targetProfitPer || "1"));
        setPayoutVal(String(p.payoutVal || "85"));
        setPayoutMode(p.payoutMode || "payout");
        setRrVal(String(p.rrVal || "2"));
        setBrokerageVal(String(p.brokerageVal || "0"));
        setBrokerageMode(p.brokerageMode || "amount");
        setTotalBrokerageAccumulated(p.totalBrokerageAccumulated || 0);
        setSessionInitial(p.sessionInitial || 1000);
        setCurrentBalance(p.currentBalance || 1000);
        setBalanceHistory(p.balanceHistory || [{ id: 0, balance: 1000 }]);
        setWins(p.wins || 0);
        setLosses(p.losses || 0);
        setConsecutiveLosses(p.consecutiveLosses || 0);
        setAutoPL(p.autoPL ?? true);
        setWinRateGuideVal(p.winRateGuideVal || "50");
        setIsSessionComplete(p.isSessionComplete || false);
        setGraphStyle(p.graphStyle || "line");
        setUserRules(p.userRules || "");
      } catch (e) {}
    }
    setIsInitialized(true);
  }, []);

  useEffect(() => {
    if (isInitialized) {
      localStorage.setItem(ADVISOR_STATE_KEY, JSON.stringify({
        initialAmount, noOfTrades, targetProfitPer, payoutVal, payoutMode, rrVal, brokerageVal,
        brokerageMode, totalBrokerageAccumulated,
        sessionInitial, currentBalance, balanceHistory, wins, losses, consecutiveLosses, autoPL, winRateGuideVal, isSessionComplete, graphStyle, userRules
      }));
    }
    if (chartScrollRef.current) {
      chartScrollRef.current.scrollLeft = chartScrollRef.current.scrollWidth;
    }
  }, [initialAmount, noOfTrades, targetProfitPer, payoutVal, payoutMode, rrVal, brokerageVal, brokerageMode, totalBrokerageAccumulated, sessionInitial, currentBalance, balanceHistory, wins, losses, consecutiveLosses, autoPL, winRateGuideVal, isInitialized, isSessionComplete, graphStyle, userRules]);

  const candleData = useMemo(() => {
    return balanceHistory.slice(1).map((item, idx) => {
      const prev = balanceHistory[idx].balance;
      const curr = item.balance;
      return {
        id: item.id,
        open: prev,
        close: curr,
        high: Math.max(prev, curr),
        low: Math.min(prev, curr),
        display: [Math.min(prev, curr), Math.max(prev, curr)],
        color: curr >= prev ? "hsl(var(--primary))" : "hsl(var(--destructive))",
        tradeAmount: item.tradeAmount,
        pnl: item.pnl,
        isWin: item.isWin,
        balance: item.balance
      };
    });
  }, [balanceHistory]);

  const totalTradesCount = wins + losses;
  const winRate = totalTradesCount > 0 ? Math.round((wins / totalTradesCount) * 100) : 0;
  const currentPL = currentBalance - sessionInitial;
  const currentPLPer = sessionInitial > 0 ? (currentPL / sessionInitial) * 100 : 0;
  const goalAmountValue = (sessionInitial * parseFloat(targetProfitPer)) / 100;
  
  const payoutFactor = payoutMode === 'payout' ? (parseFloat(payoutVal) / 100) : (parseFloat(rrVal) || 0);
  const currentBrokerageInputValue = parseFloat(brokerageVal) || 0;

  let finalReqInvest = 0;
  const targetWR = parseFloat(winRateGuideVal) || 50;
  const totalExpectedWins = Math.max(1, (parseFloat(noOfTrades) * targetWR) / 100);
  const remainingWinsNeeded = Math.max(1, totalExpectedWins - wins);
  const amountToRecover = goalAmountValue - currentPL;
  
  if (amountToRecover > 0) {
    const profitPerWinNeeded = amountToRecover / remainingWinsNeeded;
    if (brokerageMode === 'percent') {
      finalReqInvest = profitPerWinNeeded / Math.max(0.01, payoutFactor - (currentBrokerageInputValue / 100));
    } else {
      finalReqInvest = (profitPerWinNeeded + currentBrokerageInputValue) / Math.max(0.01, payoutFactor);
    }
  } else {
    finalReqInvest = currentBalance * 0.01;
  }

  const finalReqInvestPer = currentBalance > 0 ? (finalReqInvest / currentBalance) * 100 : 0;
  const nextProfit = finalReqInvest * payoutFactor;

  const handleTrade = (isWin: boolean) => {
    let profit = 0;
    let stakeUsed = 0;

    if (autoPL) {
      stakeUsed = finalReqInvest;
      if (isWin) {
        profit = nextProfit;
      } else {
        profit = -finalReqInvest;
      }
    } else {
      stakeUsed = parseFloat(lastTradePLAmount) || 0;
      if (isNaN(stakeUsed) || stakeUsed <= 0) {
        toast({ title: "Input Required", description: "Enter valid stake amount.", variant: "destructive" });
        return;
      }
      profit = isWin ? stakeUsed : -stakeUsed;
    }

    if (isWin) {
      let tradeBrokerage = 0;
      if (brokerageMode === 'percent') {
        tradeBrokerage = (stakeUsed * currentBrokerageInputValue) / 100;
      } else {
        tradeBrokerage = currentBrokerageInputValue;
      }
      
      setTotalBrokerageAccumulated(prev => prev + tradeBrokerage);
      setConsecutiveLosses(0);
    } else {
      const nextStreak = consecutiveLosses + 1;
      if (nextStreak === 2) {
        const randomQuote = PSYCHOLOGICAL_QUOTES[Math.floor(Math.random() * PSYCHOLOGICAL_QUOTES.length)];
        setDisciplineQuote(randomQuote);
        setConsecutiveLosses(0);
      } else {
        setConsecutiveLosses(nextStreak);
      }
    }

    const newBalance = currentBalance + profit;
    const newWins = isWin ? wins + 1 : wins;
    const newLosses = !isWin ? losses + 1 : losses;
    const newCurrentPL = newBalance - sessionInitial;

    setCurrentBalance(newBalance);
    setWins(newWins);
    setLosses(newLosses);
    setBalanceHistory(prev => [...prev, { 
      id: prev.length, 
      balance: Number(newBalance.toFixed(2)),
      tradeAmount: stakeUsed,
      isWin: isWin,
      pnl: profit
    }]);
    
    if (!autoPL) setLastTradePLAmount("");

    if (newCurrentPL >= goalAmountValue && !isSessionComplete) {
      setIsSessionComplete(true);
      confetti({
        particleCount: 150,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#22c55e', '#ffffff', '#10b981']
      });
    }
  };

  const startNextSession = () => {
    const finalBalance = Math.max(0, currentBalance);
    setInitialAmount(finalBalance.toFixed(2));
    setSessionInitial(finalBalance);
    setCurrentBalance(finalBalance);
    setBalanceHistory([{ id: 0, balance: finalBalance }]);
    setWins(0);
    setLosses(0);
    setConsecutiveLosses(0);
    setTotalBrokerageAccumulated(0);
    setIsSessionComplete(false);
    toast({ title: "Next Session Started", description: `Compounding with ${finalBalance.toFixed(2)}` });
  };

  const format = (v: number) => v.toLocaleString(currency === 'INR' ? 'en-IN' : 'en-US', { style: 'currency', currency });

  const chartWidthPercent = Math.max(100, (balanceHistory.length / 50) * 100);

  const yDomain = useMemo(() => {
    const recentHistory = balanceHistory.slice(-50);
    const values = recentHistory.map(b => b.balance);
    const min = Math.min(...values);
    const max = Math.max(...values);
    const range = max - min;
    const padding = range === 0 ? (min * 0.1 || 100) : range * 0.2;
    return [Number((min - padding).toFixed(2)), Number((max + padding).toFixed(2))];
  }, [balanceHistory]);

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      if (data.id === 0) return null;
      
      const stake = data.tradeAmount;
      const pnl = data.pnl;
      const win = data.isWin;
      const bal = data.balance;

      return (
        <div className="bg-background border-2 border-primary/20 p-4 rounded-3xl shadow-2xl backdrop-blur-md min-w-[160px]">
          <p className={cn("text-lg font-black uppercase mb-3 tracking-tighter", win ? "text-green-500" : "text-red-500")}>
            {win ? "TRADE WON" : "TRADE LOST"}
          </p>
          <div className="space-y-2">
            <div className="flex justify-between items-center gap-4">
              <span className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">STAKE</span>
              <span className="text-[12px] font-black uppercase tabular-nums">{format(stake || 0)}</span>
            </div>
            <div className="flex justify-between items-center gap-4">
              <span className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">P/L</span>
              <span className={cn("text-[12px] font-black uppercase tabular-nums", (pnl || 0) >= 0 ? "text-green-500" : "text-red-500")}>
                {(pnl || 0) >= 0 ? "+" : ""}{format(pnl || 0)}
              </span>
            </div>
            <div className="flex justify-between items-center gap-4 border-t border-muted/20 pt-2 mt-2">
              <span className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">BALANCE</span>
              <span className="text-[12px] font-black uppercase text-primary tabular-nums">{format(bal || 0)}</span>
            </div>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center px-4">
        <div className="space-y-0.5">
          <h2 className="text-[10px] font-black uppercase tracking-widest text-foreground/80">Trade Advisor</h2>
          <p className="text-[9px] font-bold text-muted-foreground uppercase">Institutional Binary Engine</p>
        </div>
      </div>

      <Dialog open={disciplineQuote !== null} onOpenChange={(open) => !open && setDisciplineQuote(null)}>
        <DialogContent className="bg-background border-2 border-primary/20 rounded-3xl p-8 max-w-[90vw] sm:max-w-md">
          <DialogHeader className="space-y-4 text-center">
            <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-2 border-2 border-primary/20 animate-pulse">
              <Brain className="h-8 w-8 text-primary" />
            </div>
            <DialogTitle className="text-2xl font-black uppercase tracking-tighter text-primary">Back-to-Back Loss!</DialogTitle>
            <DialogDescription className="text-foreground text-lg font-bold italic py-4 leading-relaxed uppercase tracking-tight">
              "{disciplineQuote}"
            </DialogDescription>
            <Button onClick={() => setDisciplineQuote(null)} className="w-full h-14 font-black uppercase tracking-widest text-lg border-b-4 border-primary/50 shadow-lg rounded-xl">
              I Understand
            </Button>
          </DialogHeader>
        </DialogContent>
      </Dialog>

      <Accordion type="single" collapsible className="border-none">
        <AccordionItem value="rules" className="border-2 rounded-xl bg-card shadow-sm overflow-hidden border-x-0 sm:border-x-2 border-primary/30">
          <AccordionTrigger className="px-4 py-3 hover:no-underline hover:bg-primary/5">
            <div className="flex items-center gap-2 font-black uppercase text-[11px] tracking-widest text-primary mx-auto">
              <ShieldCheck className="h-4 w-4" /> TRADING RULES & NOTES
            </div>
          </AccordionTrigger>
          <AccordionContent className="p-4 pt-2 space-y-4">
             <div className="space-y-2">
               <Label className="text-[10px] font-black uppercase text-muted-foreground tracking-widest flex items-center gap-2">
                 <Edit3 className="h-3 w-3" /> Write your session rules here
               </Label>
               <Textarea 
                placeholder="Example: 
1. Risk max 1% per trade.
2. Stop after 3 losses.
3. Only trade Order Blocks."
                value={userRules}
                onChange={(e) => setUserRules(e.target.value)}
                className="min-h-[120px] font-bold text-xs uppercase border-2 focus-visible:ring-primary rounded-xl"
               />
               <p className="text-[8px] font-bold text-muted-foreground uppercase text-center italic">Rules are saved locally on your device.</p>
             </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>

      <Accordion type="single" collapsible className="border-none">
        <AccordionItem value="settings" className="border-2 rounded-xl bg-card shadow-sm overflow-hidden border-x-0 sm:border-x-2">
          <AccordionTrigger className="px-4 py-3 hover:no-underline hover:bg-muted/5">
            <div className="flex items-center gap-2 font-black uppercase text-[11px] tracking-widest text-foreground/80">
              <Settings2 className="h-4 w-4 text-muted-foreground" /> CONFIGURATION
            </div>
          </AccordionTrigger>
          <AccordionContent className="p-4 pt-2 space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <Label className="text-[10px] font-black uppercase text-muted-foreground">Initial Amount</Label>
                <input type="number" inputMode="decimal" value={initialAmount} onChange={e => {
                  setInitialAmount(e.target.value);
                  if (totalTradesCount === 0) {
                    const val = parseFloat(e.target.value) || 0;
                    setCurrentBalance(val);
                    setSessionInitial(val);
                    setBalanceHistory([{ id: 0, balance: val }]);
                  }
                }} className="flex h-10 w-full rounded-md border-2 bg-background px-3 py-2 text-sm font-bold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2" />
              </div>
              <div className="space-y-1">
                <Label className="text-[10px] font-black uppercase text-muted-foreground">No. of Trades</Label>
                <input type="number" inputMode="decimal" value={noOfTrades} onChange={e => setNoOfTrades(e.target.value)} className="flex h-10 w-full rounded-md border-2 bg-background px-3 py-2 text-sm font-bold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <Label className="text-[10px] font-black uppercase text-muted-foreground">Target Profit (%)</Label>
                <input type="number" inputMode="decimal" value={targetProfitPer} onChange={e => setTargetProfitPer(e.target.value)} className="flex h-10 w-full rounded-md border-2 bg-background px-3 py-2 text-sm font-bold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2" />
              </div>
              <div className="space-y-1">
                <div className="flex justify-between items-center">
                  <Label className="text-[10px] font-black uppercase text-muted-foreground">
                    {payoutMode === 'payout' ? 'Payout (%)' : 'Risk:Reward (RR)'}
                  </Label>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-5 w-5 p-0 hover:bg-primary/10" 
                    onClick={() => setPayoutMode(prev => prev === "payout" ? "rr" : "payout")}
                  >
                    {payoutMode === "payout" ? <TrendingUp className="h-3 w-3" /> : <Percent className="h-3 w-3" />}
                  </Button>
                </div>
                <input 
                  type="number" 
                  inputMode="decimal"
                  value={payoutMode === 'payout' ? payoutVal : rrVal} 
                  onChange={e => payoutMode === 'payout' ? setPayoutVal(e.target.value) : setRrVal(e.target.value)} 
                  className="flex h-10 w-full rounded-md border-2 bg-background px-3 py-2 text-sm font-bold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2" 
                />
              </div>
            </div>
            <div className="grid grid-cols-1 gap-4">
              <div className="space-y-1">
                <div className="flex justify-between items-center">
                  <Label className="text-[10px] font-black uppercase text-muted-foreground">
                    Brokerage per Win ({brokerageMode === 'amount' ? CURRENCY_SYMBOLS[currency] : '%'})
                  </Label>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-5 w-5 p-0 hover:bg-primary/10" 
                    onClick={() => setBrokerageMode(prev => prev === "amount" ? "percent" : "amount")}
                  >
                    {brokerageMode === "amount" ? <Percent className="h-3 w-3" /> : <span className="text-[11px] font-black">{CURRENCY_SYMBOLS[currency]}</span>}
                  </Button>
                </div>
                <input type="number" inputMode="decimal" value={brokerageVal} onChange={e => setBrokerageVal(e.target.value)} className="flex h-10 w-full rounded-md border-2 bg-background px-3 py-2 text-sm font-bold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2" />
              </div>
            </div>
            <Button variant="outline" onClick={startNextSession} className="w-full h-10 font-black uppercase text-xs gap-2 border-2 hover:bg-destructive/10 hover:text-destructive rounded-xl">
               <RefreshCcw className="h-4 w-4" /> Reset Session
            </Button>
          </AccordionContent>
        </AccordionItem>
      </Accordion>

      <Card className="shadow-sm border-2 bg-card rounded-2xl overflow-hidden relative border-x-0 sm:border-x-2">
        <CardContent className="p-4 space-y-6">
          {isSessionComplete && (
            <div className="absolute inset-0 z-50 flex items-center justify-center bg-background/90 backdrop-blur-sm animate-in fade-in duration-500">
              <div className="text-center space-y-4 p-8">
                <div className="bg-primary/20 h-16 w-16 rounded-full flex items-center justify-center mx-auto mb-2 animate-bounce">
                  <PartyPopper className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-2xl font-black uppercase tracking-tighter">Congratulations!</h3>
                <p className="text-sm font-bold text-muted-foreground uppercase leading-tight">
                  Target reached.<br/>New Balance: <span className="text-primary">{format(currentBalance)}</span>
                </p>
                <Button onClick={startNextSession} className="w-full h-14 font-black uppercase tracking-widest text-lg border-b-4 border-primary/50 shadow-lg rounded-xl">
                  Start Next Session
                </Button>
              </div>
            </div>
          )}

          <div className="flex justify-between items-start">
            <div className="flex flex-col">
              <p className="text-[9px] font-bold text-muted-foreground uppercase tracking-widest">Session Balance</p>
              <h2 className="text-3xl font-black tracking-tight tabular-nums">{format(currentBalance)}</h2>
            </div>
            <div className="flex border-2 rounded-lg overflow-hidden bg-muted/20">
              <Button 
                variant={graphStyle === "candle" ? "default" : "ghost"} 
                size="icon" 
                onClick={() => setGraphStyle("candle")}
                className={cn("h-8 w-8 rounded-none", graphStyle === "candle" && "bg-primary text-white")}
              >
                <CandlestickChart className="h-4 w-4" />
              </Button>
              <Button 
                variant={graphStyle === "line" ? "default" : "ghost"} 
                size="icon" 
                onClick={() => setGraphStyle("line")}
                className={cn("h-8 w-8 rounded-none", graphStyle === "line" && "bg-primary text-white")}
              >
                <LineChart className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div 
            ref={chartScrollRef} 
            className="h-[180px] w-full mt-2 -mx-4 overflow-x-auto no-scrollbar touch-pan-x"
          >
             <div style={{ width: `${chartWidthPercent}%`, minWidth: '100%' }} className="h-full">
               <ResponsiveContainer width="100%" height="100%">
                 {graphStyle === "line" ? (
                   <AreaChart data={balanceHistory} margin={{ top: 15, right: 0, left: 0, bottom: 5 }}>
                     <defs>
                       <linearGradient id="colorBalance" x1="0" y1="0" x2="0" y2="1">
                         <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                         <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                       </linearGradient>
                     </defs>
                     <ChartTooltip content={<CustomTooltip />} />
                     <Area 
                       type="monotone" 
                       dataKey="balance" 
                       stroke="hsl(var(--primary))" 
                       strokeWidth={3}
                       fillOpacity={1} 
                       fill="url(#colorBalance)" 
                       animationDuration={300}
                       isAnimationActive={true}
                     />
                     <XAxis dataKey="id" hide />
                     <YAxis domain={yDomain} hide />
                   </AreaChart>
                 ) : (
                   <ReBarChart data={candleData} margin={{ top: 15, right: 0, left: 0, bottom: 5 }}>
                     <ChartTooltip content={<CustomTooltip />} />
                     <XAxis dataKey="id" hide />
                     <YAxis domain={yDomain} hide />
                     <Bar dataKey="display" animationDuration={300} radius={[2, 2, 2, 2]}>
                       {candleData.map((entry) => (
                         <Cell key={`cell-${entry.id}`} fill={entry.color} />
                       ))}
                     </Bar>
                   </ReBarChart>
                 )}
               </ResponsiveContainer>
             </div>
          </div>

          <div className="grid grid-cols-4 gap-1">
            <div className="bg-green-500/10 p-2 rounded-xl text-center space-y-1 border border-green-500/20">
              <p className="text-[7px] font-bold text-green-600 uppercase">Wins</p>
              <p className="text-base font-black text-green-600">{wins}</p>
            </div>
            <div className="bg-red-500/10 p-2 rounded-xl text-center space-y-1 border border-red-500/20">
              <p className="text-[7px] font-bold text-red-600 uppercase">Losses</p>
              <p className="text-base font-black text-red-600">{losses}</p>
            </div>
            <div className="bg-muted/10 p-2 rounded-xl text-center space-y-1 border border-muted/20">
              <p className="text-[7px] font-bold text-muted-foreground uppercase">Win Rate</p>
              <p className="text-base font-black">{winRate}%</p>
            </div>
            <div className="bg-muted/10 p-2 rounded-xl text-center space-y-1 border border-muted/20">
              <p className="text-[7px] font-bold text-muted-foreground uppercase">Trades</p>
              <p className="text-[10px] font-black pt-1 leading-tight">{totalTradesCount} / {noOfTrades}</p>
            </div>
          </div>

          <div className="text-center space-y-1">
            <p className="text-[9px] font-bold text-muted-foreground uppercase tracking-widest">Current P/L</p>
            <div className={cn("text-4xl font-black tracking-tight tabular-nums", currentPL >= 0 ? "text-green-500" : "text-red-500")}>
              {currentPL >= 0 ? "+" : ""}{format(currentPL)}
            </div>
            <p className={cn("text-[11px] font-bold", currentPL >= 0 ? "text-green-500" : "text-red-500")}>({currentPLPer.toFixed(2)}%)</p>
            <p className="text-[8px] font-bold text-muted-foreground uppercase tracking-tighter">Total Brokerage: {format(totalBrokerageAccumulated)}</p>
          </div>

          <div className="relative flex items-center justify-center py-2">
            <div className="absolute inset-x-0 h-[1px] bg-muted/30" />
            <div className="relative bg-card px-3 text-[9px] font-bold text-muted-foreground uppercase tracking-widest flex items-center gap-2">
              <Trophy className="h-3 w-3 text-yellow-500" /> Goal: {format(goalAmountValue)} ({targetProfitPer}%)
            </div>
          </div>

          <div className="rounded-2xl border-2 border-muted/20 p-4 space-y-6 bg-muted/5">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 border-2 rounded-lg px-2 h-9 bg-background">
                <input type="number" inputMode="decimal" value={winRateGuideVal} onChange={e => setWinRateGuideVal(e.target.value)} className="w-10 h-full border-none p-0 text-center font-bold focus-visible:ring-0 bg-transparent" />
              </div>
              <span className="text-[10px] font-bold uppercase text-muted-foreground tracking-widest">% Win Rate Target</span>
            </div>

            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="space-y-1 border-r-2 border-muted/20">
                <p className="text-[8px] font-bold text-green-500 uppercase tracking-tighter">REQ. INVEST %</p>
                <p className="text-[14px] font-black text-green-500">+{finalReqInvestPer.toFixed(2)}%</p>
              </div>
              <div className="space-y-1 border-r-2 border-muted/20">
                <p className="text-[8px] font-bold text-muted-foreground uppercase tracking-widest text-center">REQ. INVEST</p>
                <p className="text-[14px] font-black text-foreground">{format(finalReqInvest)}</p>
              </div>
              <div className="space-y-1">
                <p className="text-[8px] font-bold text-muted-foreground uppercase tracking-widest text-center">NEXT PROFIT</p>
                <p className="text-[14px] font-black text-foreground">{format(nextProfit)}</p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4 bg-muted/10 p-4 rounded-2xl border-2 border-dashed border-muted/30">
            <div className="flex flex-col items-center gap-2 flex-1 border-r-2 border-muted/20 pr-4">
              <Switch checked={autoPL} onCheckedChange={setAutoPL} className="data-[state=checked]:bg-green-500" />
              <span className="text-[9px] font-bold uppercase text-muted-foreground tracking-widest whitespace-nowrap">Auto P/L Mode</span>
            </div>
            <div className="flex-1 space-y-1">
              <p className="text-[8px] font-bold text-muted-foreground uppercase tracking-widest text-center">STAKE AMOUNT</p>
              <input
                type="number"
                inputMode="decimal"
                placeholder="0.00"
                value={lastTradePLAmount}
                onChange={e => setLastTradePLAmount(e.target.value)}
                disabled={autoPL}
                className={cn(
                  "flex h-12 w-full text-center text-xl font-black rounded-xl border-2 transition-all bg-background",
                  autoPL ? "opacity-30 grayscale border-muted" : "border-green-500 focus-visible:ring-green-500"
                )}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <Button
              onClick={() => handleTrade(true)}
              className="bg-green-500/10 hover:bg-green-500/20 dark:bg-green-950/50 text-green-600 h-16 font-black text-xl uppercase rounded-xl gap-2 border-0"
            >
              <ArrowUpRight className="h-6 w-6" /> WON
            </Button>
            <Button
              onClick={() => handleTrade(false)}
              className="bg-red-500/10 hover:bg-red-500/20 dark:bg-red-950/50 text-red-600 h-16 font-black text-xl uppercase rounded-xl gap-2 border-0"
            >
              <ArrowDownRight className="h-6 w-6" /> LOST
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function ArticleSection() {
  const articles = [
    { title: "Binary Options Math: Beating Payouts", slug: "binary-math", desc: "How to mathematically overcome the negative expectancy." },
    { title: "Institutional Order Blocks Guide", slug: "order-blocks", desc: "Identifying where big money enters the market." },
    { title: "Liquidity Sweeps Strategy", slug: "liquidity-sweeps", desc: "Trading against common retail stop losses." },
    { title: "Fair Value Gaps (FVG) Secrets", slug: "fvg-secrets", desc: "Spotting market imbalances for high accuracy entries." },
    { title: "Trading Psychology: Stop Revenge Trading", slug: "revenge-trading", desc: "Mastering your emotions after a losing streak." },
    { title: "Advanced Risk Management 101", slug: "risk-management", desc: "Why lot sizing is more important than your entry." },
    { title: "SMC: Smart Money Concepts", slug: "smc-intro", desc: "Complete introduction to institutional trading flow." },
    { title: "Forex Scalping Mastery", slug: "forex-scalping", desc: "1-minute strategies for consistent daily profits." },
    { title: "Using ATR for Volatility", slug: "atr-volatility", desc: "Adjusting your stops based on current market noise." },
    { title: "The Power of Compounding", slug: "compounding", desc: "Turning small accounts into fortunes systematically." },
    { title: "News Trading Strategy", slug: "news-trading", desc: "How to survive and profit from NFP and CPI events." },
    { title: "Support/Resistance vs Supply/Demand", slug: "s-r-vs-s-d", desc: "Choosing the right zones for your trade." },
    { title: "Daily Session Planning", slug: "session-plan", desc: "Building a professional routine for consistency." },
    { title: "Price Action Candlesticks", slug: "candlestick-secrets", desc: "Reading the story behind every wick and body." },
    { title: "The Road to Full-Time Trading", slug: "full-time-trading", desc: "A realistic roadmap to financial freedom." }
  ];

  return (
    <div className="grid gap-4 px-4">
      <div className="flex items-center gap-2 mb-2">
        <BookOpen className="h-5 w-5 text-primary" />
        <h2 className="text-sm font-black uppercase tracking-widest">Trading Academy</h2>
      </div>
      {articles.map((art, i) => (
        <Link key={`art-${i}`} href={`/articles/${art.slug}`}>
          <Card className="hover:border-primary/50 transition-all border-2 bg-card cursor-pointer group rounded-xl">
            <CardHeader className="p-4">
              <div className="flex justify-between items-start">
                <h3 className="font-black text-sm uppercase group-hover:text-primary transition-colors">{art.title}</h3>
                <ChevronRight className="h-4 w-4 text-muted-foreground" />
              </div>
              <p className="text-[10px] text-muted-foreground font-bold mt-1 uppercase">{art.desc}</p>
            </CardHeader>
          </Card>
        </Link>
      ))}
    </div>
  );
}

function StockStopLossCalculator({ currency }: { currency: Currency }) {
  const [cap, setCap] = useState("100000");
  const [riskMode, setRiskMode] = useState<"percent" | "amount">("percent");
  const [riskVal, setRiskVal] = useState("1");
  const [entry, setEntry] = useState("100");
  const [sl, setSl] = useState("95");
  const [isInitialized, setIsInitialized] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem(STOCK_SL_STATE_KEY);
    if (saved) {
      try {
        const p = JSON.parse(saved);
        setCap(String(p.cap || "100000"));
        setRiskMode(p.riskMode || "percent");
        setRiskVal(String(p.riskVal || "1"));
        setEntry(String(p.entry || "100"));
        setSl(String(p.sl || "95"));
      } catch (e) {}
    }
    setIsInitialized(true);
  }, []);

  useEffect(() => {
    if (isInitialized) {
      localStorage.setItem(STOCK_SL_STATE_KEY, JSON.stringify({
        cap, riskMode, riskVal, entry, sl
      }));
    }
  }, [cap, riskMode, riskVal, entry, sl, isInitialized]);

  const riskAmt = useMemo(() => {
    const capital = parseFloat(cap) || 0;
    const value = parseFloat(riskVal) || 0;
    if (riskMode === "percent") {
      return (capital * value) / 100;
    }
    return value;
  }, [cap, riskMode, riskVal]);

  const diff = Math.abs(parseFloat(entry) - parseFloat(sl));
  const qty = diff > 0 ? Math.floor(riskAmt / diff) : 0;
  const totalInvestment = qty * (parseFloat(entry) || 0);
  
  const format = (v: number) => v.toLocaleString(currency === 'INR' ? 'en-IN' : 'en-US', { style: 'currency', currency });
  const currentSymbol = CURRENCY_SYMBOLS[currency];

  return (
    <Card className="shadow-xl border-2 bg-card rounded-2xl overflow-hidden border-x-0 sm:border-x-2">
      <CardHeader className="p-6 border-b bg-muted/10">
        <CardTitle className="text-xl font-black uppercase tracking-tight text-center">STOCK RISK CALCULATOR</CardTitle>
      </CardHeader>
      <CardContent className="p-6 space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label className="text-[10px] uppercase font-black text-muted-foreground tracking-widest">CAPITAL</Label>
            <Input type="number" inputMode="decimal" value={cap} onChange={e => setCap(e.target.value)} className="h-12 border-2 font-black rounded-xl bg-background" />
          </div>
          <div className="space-y-1.5">
            <div className="flex justify-between items-center">
              <Label className="text-[10px] uppercase font-black text-muted-foreground tracking-widest">RISK ({riskMode === "percent" ? "%" : currentSymbol})</Label>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-5 w-5 p-0 hover:bg-primary/10" 
                onClick={() => setRiskMode(prev => prev === "percent" ? "amount" : "percent")}
              >
                {riskMode === "percent" ? <span className="text-[11px] font-black">{currentSymbol}</span> : <Percent className="h-3 w-3" />}
              </Button>
            </div>
            <Input type="number" inputMode="decimal" value={riskVal} onChange={e => setRiskVal(e.target.value)} className="h-12 border-2 font-black rounded-xl bg-background border-primary/50" />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label className="text-[10px] uppercase font-black text-muted-foreground tracking-widest">ENTRY PRICE</Label>
            <Input type="number" inputMode="decimal" value={entry} onChange={e => setEntry(e.target.value)} className="h-12 border-2 font-black rounded-xl bg-background" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-[10px] uppercase font-black text-muted-foreground tracking-widest">STOP LOSS</Label>
            <Input type="number" inputMode="decimal" value={sl} onChange={e => setSl(e.target.value)} className="h-12 border-2 font-black rounded-xl bg-background" />
          </div>
        </div>
        <div className="bg-primary/5 p-8 rounded-3xl text-center border-2 border-dashed border-primary/30 mt-4 space-y-4">
          <div className="space-y-1">
            <div className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">BUY QUANTITY</div>
            <div className="text-6xl font-black text-primary tracking-tighter tabular-nums">{qty}</div>
          </div>
          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-dashed border-primary/20">
            <div className="space-y-0.5">
              <div className="text-[8px] font-black uppercase text-muted-foreground tracking-widest">MAX RISK</div>
              <div className="text-[11px] font-black text-red-500 uppercase">{format(riskAmt)}</div>
            </div>
            <div className="space-y-0.5">
              <div className="text-[8px] font-black uppercase text-muted-foreground tracking-widest">INVESTMENT</div>
              <div className="text-[11px] font-black text-green-500 uppercase">{format(totalInvestment)}</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function ForexStopLossCalculator({ currency }: { currency: Currency }) {
  const [bal, setBal] = useState("10000");
  const [riskMode, setRiskMode] = useState<"percent" | "amount">("percent");
  const [riskVal, setRiskVal] = useState("1");
  const [pips, setPips] = useState("30");
  const [isInitialized, setIsInitialized] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem(FOREX_LOT_STATE_KEY);
    if (saved) {
      try {
        const p = JSON.parse(saved);
        setBal(String(p.bal || "10000"));
        setRiskMode(p.riskMode || "percent");
        setRiskVal(String(p.riskVal || "1"));
        setPips(String(p.pips || "30"));
      } catch (e) {}
    }
    setIsInitialized(true);
  }, []);

  useEffect(() => {
    if (isInitialized) {
      localStorage.setItem(FOREX_LOT_STATE_KEY, JSON.stringify({
        bal, riskMode, riskVal, pips
      }));
    }
  }, [bal, riskMode, riskVal, pips, isInitialized]);

  const riskAmt = useMemo(() => {
    const balance = parseFloat(bal) || 0;
    const val = parseFloat(riskVal) || 0;
    if (riskMode === "percent") {
      return (balance * val) / 100;
    }
    return val;
  }, [bal, riskMode, riskVal]);

  const lotSize = parseFloat(pips) > 0 ? riskAmt / (parseFloat(pips) * 10) : 0;
  const format = (v: number) => v.toLocaleString(currency === 'INR' ? 'en-IN' : 'en-US', { style: 'currency', currency });
  const currentSymbol = CURRENCY_SYMBOLS[currency];

  return (
    <Card className="shadow-xl border-2 bg-card rounded-2xl overflow-hidden border-x-0 sm:border-x-2">
      <CardHeader className="p-6 border-b bg-muted/10">
        <CardTitle className="text-xl font-black uppercase tracking-tight text-center">FOREX LOT SIZER</CardTitle>
      </CardHeader>
      <CardContent className="p-6 space-y-6">
        <div className="space-y-1.5">
          <Label className="text-[10px] uppercase font-black text-muted-foreground tracking-widest">ACCOUNT BALANCE</Label>
          <Input type="number" inputMode="decimal" value={bal} onChange={e => setBal(e.target.value)} className="h-12 border-2 font-black rounded-xl bg-background" />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <div className="flex justify-between items-center">
              <Label className="text-[10px] uppercase font-black text-muted-foreground tracking-widest">RISK ({riskMode === "percent" ? "%" : currentSymbol})</Label>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-5 w-5 p-0 hover:bg-primary/10" 
                onClick={() => setRiskMode(prev => prev === "percent" ? "amount" : "percent")}
              >
                {riskMode === "percent" ? <span className="text-[11px] font-black">{currentSymbol}</span> : <Percent className="h-3 w-3" />}
              </Button>
            </div>
            <Input type="number" inputMode="decimal" value={riskVal} onChange={e => setRiskVal(e.target.value)} className="h-12 border-2 font-black rounded-xl bg-background border-primary/50" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-[10px] uppercase font-black text-muted-foreground tracking-widest">SL PIPS</Label>
            <Input type="number" inputMode="decimal" value={pips} onChange={e => setPips(e.target.value)} className="h-12 border-2 font-black rounded-xl bg-background" />
          </div>
        </div>
        <div className="bg-primary/5 p-8 rounded-3xl text-center border-2 border-dashed border-primary/30 mt-4 space-y-4">
          <div className="space-y-1">
            <div className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">POSITION SIZE (LOTS)</div>
            <div className="text-6xl font-black text-primary tracking-tighter tabular-nums">{lotSize.toFixed(2)}</div>
          </div>
          <div className="pt-2 border-t border-dashed border-primary/20">
            <div className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">RISK AMOUNT: <span className="text-foreground">{format(riskAmt)}</span></div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Home() {
  const [activeTab, setActiveTab] = useState("articles");
  const [currency, setCurrency] = useState<Currency>("INR");
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const prefs = localStorage.getItem(PREFERENCES_KEY);
    if (prefs) {
      try {
        const { currency: c } = JSON.parse(prefs);
        setCurrency(c || "INR");
      } catch (e) {}
    }
    setIsLoaded(true);
  }, []);

  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem(PREFERENCES_KEY, JSON.stringify({ currency }));
    }
  }, [currency, isLoaded]);

  if (!isLoaded) return null;

  return (
    <div className="min-h-screen bg-background font-body pb-12 w-full max-w-full overflow-x-hidden">
      <header className="sticky top-0 z-[60] w-full border-b-2 bg-background/95 backdrop-blur shadow-sm">
        <div className="flex h-16 items-center justify-between px-2 max-w-full">
          <div className="flex items-center gap-2">
            <BarChart3 className="h-6 w-6 text-primary" />
            <h1 className="text-lg font-black uppercase tracking-tighter">Trading Calculators</h1>
          </div>
          <ThemeToggle />
        </div>
      </header>
      
      <FloatingClock />

      <main className="w-full px-0 py-6 space-y-6 max-w-full">
        <div className="flex items-center justify-between bg-card p-4 border-y-2 border-x-0 shadow-sm mx-0">
           <Label className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">Terminal Currency</Label>
           <Select value={currency} onValueChange={(v: any) => setCurrency(v)}>
             <SelectTrigger className="h-9 w-32 font-black text-xs uppercase border-2 bg-background rounded-lg"><SelectValue /></SelectTrigger>
             <SelectContent>
               <SelectItem value="INR" className="font-bold">INR (₹)</SelectItem>
               <SelectItem value="USD" className="font-bold">USD ($)</SelectItem>
               <SelectItem value="EUR" className="font-bold">EUR (€)</SelectItem>
               <SelectItem value="GBP" className="font-bold">GBP (£)</SelectItem>
             </SelectContent>
           </Select>
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="px-0">
            <TabsList className="grid w-full grid-cols-7 h-14 bg-card p-1 border-y-2 border-x-0 rounded-none shadow-sm overflow-x-auto no-scrollbar">
              <TabsTrigger value="articles" className="uppercase font-black text-[8px] tracking-tight data-[state=active]:bg-primary data-[state=active]:text-white rounded-xl transition-all min-w-[55px]">Academy</TabsTrigger>
              <TabsTrigger value="advisor" className="uppercase font-black text-[8px] tracking-tight data-[state=active]:bg-primary data-[state=active]:text-white rounded-xl transition-all min-w-[55px]">Advisor</TabsTrigger>
              <TabsTrigger value="signals" className="uppercase font-black text-[8px] tracking-tight data-[state=active]:bg-primary data-[state=active]:text-white rounded-xl transition-all min-w-[55px]">AI Feed</TabsTrigger>
              <TabsTrigger value="wealth" className="uppercase font-black text-[8px] tracking-tight data-[state=active]:bg-primary data-[state=active]:text-white rounded-xl transition-all min-w-[55px]">Wealth</TabsTrigger>
              <TabsTrigger value="stock" className="uppercase font-black text-[8px] tracking-tight data-[state=active]:bg-primary data-[state=active]:text-white rounded-xl transition-all min-w-[55px]">Stock SL</TabsTrigger>
              <TabsTrigger value="forex" className="uppercase font-black text-[8px] tracking-tight data-[state=active]:bg-primary data-[state=active]:text-white rounded-xl transition-all min-w-[55px]">Lot Size</TabsTrigger>
              <TabsTrigger value="portfolio" className="uppercase font-black text-[8px] tracking-tight data-[state=active]:bg-primary data-[state=active]:text-white rounded-xl transition-all min-w-[55px]">Portfolio</TabsTrigger>
            </TabsList>
          </div>
          <div className="px-0">
            <TabsContent value="articles" className="pt-4 px-0"><ArticleSection /></TabsContent>
            <TabsContent value="advisor" className="pt-4 px-0"><TradeAdvisorCalculator currency={currency} /></TabsContent>
            <TabsContent value="signals" className="pt-4 px-0"><TradingSignals /></TabsContent>
            <TabsContent value="wealth" className="pt-4 px-0"><WealthManager currency={currency} /></TabsContent>
            <TabsContent value="stock" className="pt-4 px-0"><StockStopLossCalculator currency={currency} /></TabsContent>
            <TabsContent value="forex" className="pt-4 px-0"><ForexStopLossCalculator currency={currency} /></TabsContent>
            <TabsContent value="portfolio" className="pt-4 px-0"><PortfolioManager currency={currency} /></TabsContent>
          </div>
        </Tabs>

        <div className="space-y-4 pt-6 border-t-2 px-0">
          <div className="flex items-center gap-2 px-4"><Globe className="h-5 w-5 text-primary" /><h2 className="text-sm font-black uppercase tracking-widest">Market Context</h2></div>
          <Card className="overflow-hidden border-2 rounded-2xl group cursor-pointer hover:border-primary/50 transition-all bg-card w-full rounded-none border-x-0">
            <div className="aspect-video relative bg-muted overflow-hidden">
               <img src="https://picsum.photos/seed/marketnews/600/340" alt="News" className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-500" />
               <div className="absolute top-2 left-2 bg-red-600 text-white text-[10px] font-black px-2 py-1 rounded uppercase animate-pulse">Institutional Feed</div>
            </div>
            <CardContent className="p-4 space-y-2">
               <h3 className="font-black text-sm uppercase leading-tight">Gemini AI detects institutional mitigation near current liquidity pools</h3>
               <p className="text-[11px] text-muted-foreground font-bold leading-relaxed">HFT analysis suggests a volatility spike in the major FX pairs within the next 15-minute window.</p>
               <div className="flex items-center text-[10px] font-black text-primary uppercase pt-1">
                 View Full Analysis <ChevronRight className="h-3 w-3 ml-1" />
               </div>
            </CardContent>
          </Card>
        </div>
      </main>
      <footer className="mt-8 border-t-2 bg-card py-8 text-center shadow-inner w-full">
        <div className="flex justify-center items-center gap-6 mb-4">
           <Link href="/articles" className="text-[10px] font-black uppercase hover:text-primary transition-colors tracking-widest">Articles</Link>
           <Link href="/terms" className="text-[10px] font-black uppercase hover:text-primary transition-colors tracking-widest">Terms</Link>
           <Link href="/contact" className="text-[10px] font-black uppercase hover:text-primary transition-colors tracking-widest">Contact</Link>
        </div>
        <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">© {new Date().getFullYear()} tacalculator.com</p>
      </footer>
    </div>
  );
}
