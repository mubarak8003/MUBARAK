
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { ChevronLeft, ShieldCheck, Target, AlertTriangle } from 'lucide-react';

export const metadata = {
  title: 'Mastering the Stop-Loss: Protect Your Trading Capital | tacalculator.com',
  description: 'Why every successful trader prioritizes capital protection. Learn professional stop-loss placement techniques.',
};

export default function StopLossArticle() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b bg-background/95 backdrop-blur sticky top-0 z-50">
        <div className="container flex h-14 items-center px-4 max-w-2xl mx-auto">
          <Link href="/articles" className="text-sm font-black uppercase tracking-tighter hover:text-primary transition-colors flex items-center gap-1">
            <ChevronLeft className="h-4 w-4" /> All Articles
          </Link>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-2xl">
        <article className="space-y-8 prose prose-neutral dark:prose-invert">
          <div className="space-y-4 text-center">
            <span className="text-[10px] font-bold uppercase tracking-widest text-primary px-3 py-1 bg-primary/5 rounded-full border border-primary/20">
              Risk Management
            </span>
            <h1 className="text-4xl font-black uppercase tracking-tighter leading-none m-0">
              Mastering the Stop-Loss: Protecting Your Capital
            </h1>
            <p className="text-muted-foreground text-sm italic">
              Published on March 6, 2024 • 6 min read
            </p>
          </div>

          <p className="text-lg leading-relaxed">
            In trading, you can't control the market, but you can control your <strong>exit</strong>. A stop-loss is your insurance policy against a market crash. This guide explains why it's the most important order you'll ever place.
          </p>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold uppercase flex items-center gap-2">
              <ShieldCheck className="h-6 w-6 text-primary" /> What is a Stop-Loss?
            </h2>
            <p>
              A stop-loss order is an order placed with a broker to buy or sell a specific stock or currency once the price reaches a certain level. It is designed to limit an investor's loss on a security position.
            </p>
            <div className="bg-destructive/5 p-6 rounded-xl border border-destructive/20 font-medium italic">
              "A stop-loss isn't just a number; it's a commitment to live and trade another day."
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold uppercase flex items-center gap-2">
              <Target className="h-6 w-6 text-primary" /> Where to Place Your Stop-Loss
            </h2>
            <p>
              Placement should never be random. Professional traders use logic-based levels:
            </p>
            <ul className="list-disc pl-6 space-y-2">
              <li><strong>Support/Resistance:</strong> Placing the stop just below support in a long trade.</li>
              <li><strong>Moving Averages:</strong> Using key trendlines as dynamic stop-loss levels.</li>
              <li><strong>Volatility (ATR):</strong> Adjusting your stop distance based on current market noise.</li>
            </ul>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold uppercase flex items-center gap-2">
              <AlertTriangle className="h-6 w-6 text-primary" /> The Danger of "Mental" Stops
            </h2>
            <p>
              New traders often say they have a "mental stop-loss." In reality, when the price hits that level, emotions take over and they refuse to close the trade, leading to catastrophic losses. Always place your stop-loss order <strong>electronically</strong> the moment you enter a trade.
            </p>
          </section>

          <Separator className="my-8" />

          <div className="bg-primary/5 p-8 rounded-2xl border border-primary/10 space-y-4 text-center">
            <h3 className="text-xl font-bold uppercase">Stop Losing More Than You Should</h3>
            <p className="text-sm text-muted-foreground">
              Use our Stock Stop-Loss Calculator to determine your risk and reward ratios before you click buy.
            </p>
            <div className="flex justify-center">
              <Button asChild className="font-bold uppercase h-12 px-8">
                <Link href="/">Open Calculator</Link>
              </Button>
            </div>
          </div>
        </article>
      </main>

      <footer className="mt-12 border-t bg-muted/50 py-12">
        <div className="container mx-auto px-4 text-center">
          <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-2">tacalculator.com</p>
          <p className="text-xs text-muted-foreground">© {new Date().getFullYear()} Expert Financial Education.</p>
        </div>
      </footer>
    </div>
  );
}
