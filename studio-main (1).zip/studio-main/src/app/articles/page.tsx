
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { BookOpen, ChevronRight, Calculator, BarChart3, ShieldCheck } from 'lucide-react';

export const metadata = {
  title: 'Trading Guides & Articles | tacalculator.com',
  description: 'Learn professional trading strategies, risk management, and how to use our free financial tools to improve your trading performance.',
};

const articles = [
  {
    title: "How to Calculate Forex Position Size: A Complete Guide",
    description: "Mastering position sizing is the most important skill in forex trading. Learn why and how to calculate it for every trade.",
    slug: "forex-position-sizing",
    icon: <Calculator className="h-6 w-6 text-primary" />,
    category: "Forex"
  },
  {
    title: "Why Every Trader Needs a Stop Loss: Protecting Your Capital",
    description: "Capital preservation is the first rule of trading. Discover professional stop-loss strategies to survive and thrive.",
    slug: "stop-loss-strategy",
    icon: <ShieldCheck className="h-6 w-6 text-primary" />,
    category: "Risk Management"
  },
  {
    title: "Mastering Trade Discipline with the Trade Advisor Tool",
    description: "Stop emotional trading and start following a data-driven session plan. Learn how to use our Trade Advisor for better results.",
    slug: "trading-discipline",
    icon: <BarChart3 className="h-6 w-6 text-primary" />,
    category: "Psychology"
  }
];

export default function ArticlesPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b bg-background/95 backdrop-blur sticky top-0 z-50">
        <div className="container flex h-14 items-center px-4 max-w-2xl mx-auto">
          <Link href="/" className="text-sm font-black uppercase tracking-tighter hover:text-primary transition-colors">
            &larr; Back to Calculators
          </Link>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-2xl">
        <div className="space-y-2 mb-8 text-center">
          <h1 className="text-3xl font-black uppercase tracking-tighter">Trading Guides & Articles</h1>
          <p className="text-muted-foreground text-sm">Empower your trading decisions with our educational resources.</p>
        </div>

        <div className="grid gap-6">
          {articles.map((article) => (
            <Link key={article.slug} href={`/articles/${article.slug}`} className="group">
              <Card className="hover:border-primary/50 transition-all duration-300 overflow-hidden">
                <div className="p-6 flex gap-4">
                  <div className="shrink-0 p-3 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors">
                    {article.icon}
                  </div>
                  <div className="space-y-2 flex-1">
                    <div className="flex justify-between items-start">
                      <span className="text-[10px] font-bold uppercase tracking-widest text-primary px-2 py-0.5 bg-primary/5 rounded border border-primary/10">
                        {article.category}
                      </span>
                    </div>
                    <h2 className="text-xl font-bold group-hover:text-primary transition-colors leading-tight">
                      {article.title}
                    </h2>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {article.description}
                    </p>
                    <div className="flex items-center text-xs font-bold text-primary uppercase pt-2">
                      Read Full Guide <ChevronRight className="ml-1 h-3 w-3" />
                    </div>
                  </div>
                </div>
              </Card>
            </Link>
          ))}
        </div>

        <div className="mt-16 p-8 rounded-2xl bg-primary/5 border border-primary/10 text-center space-y-4">
          <BookOpen className="h-10 w-10 text-primary mx-auto" />
          <h3 className="text-xl font-bold uppercase">More Guides Coming Soon</h3>
          <p className="text-sm text-muted-foreground max-w-sm mx-auto">
            We are constantly writing new educational content to help you become a more disciplined and profitable trader. Stay tuned!
          </p>
          <Button variant="default" asChild className="font-bold uppercase">
            <Link href="/">Back to Tools</Link>
          </Button>
        </div>
      </main>

      <footer className="mt-8 border-t bg-muted/50 py-12">
        <div className="container mx-auto px-4 text-center">
          <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-2">tacalculator.com</p>
          <p className="text-xs text-muted-foreground">© {new Date().getFullYear()} All Rights Reserved.</p>
        </div>
      </footer>
    </div>
  );
}
