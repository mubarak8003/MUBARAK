
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { ChevronLeft, BarChart3, Brain, Zap } from 'lucide-react';

export const metadata = {
  title: 'Mastering Trade Discipline with the Trade Advisor Tool | tacalculator.com',
  description: 'How to use session-based planning to stop emotional trading and achieve consistent profits.',
};

export default function TradingDisciplineArticle() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b bg-background/95 backdrop-blur sticky top-0 z-50">
        <div className="container flex h-14 items-center px-4 max-w-2xl mx-auto">
          <Link href="/articles" className="text-sm font-black uppercase tracking-tighter hover:text-primary transition-colors flex items-center gap-1">
            <ChevronLeft className="h-4 w-4" /> All Articles
          </Link>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-2xl">
        <article className="space-y-8 prose prose-neutral dark:prose-invert">
          <div className="space-y-4 text-center">
            <span className="text-[10px] font-bold uppercase tracking-widest text-primary px-3 py-1 bg-primary/5 rounded-full border border-primary/20">
              Trading Psychology
            </span>
            <h1 className="text-4xl font-black uppercase tracking-tighter leading-none m-0">
              Mastering Trade Discipline with the Trade Advisor Tool
            </h1>
            <p className="text-muted-foreground text-sm italic">
              Published on March 6, 2024 • 7 min read
            </p>
          </div>

          <p className="text-lg leading-relaxed">
            The difference between a successful trader and a gambler is <strong>discipline</strong>. Our Trade Advisor tool was built to help you bridge that gap by treating every trading session as a business plan.
          </p>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold uppercase flex items-center gap-2">
              <Brain className="h-6 w-6 text-primary" /> The Psychology of Revenge Trading
            </h2>
            <p>
              Most traders lose their entire account in a single day of "revenge trading"—trying to win back losses immediately. Discipline fails because the brain's emotional center takes over. To combat this, you need an external system to track your progress and tell you when to stop.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold uppercase flex items-center gap-2">
              <BarChart3 className="h-6 w-6 text-primary" /> How the Trade Advisor Helps
            </h2>
            <p>
              The Trade Advisor isn't just a calculator; it's a session manager. By setting a "Target Profit" and a "Number of Trades," you create a boundary for your behavior:
            </p>
            <ul className="list-disc pl-6 space-y-2">
              <li><strong>Session Goals:</strong> Know exactly when you've reached your daily target and stop.</li>
              <li><strong>Risk per Win:</strong> It tells you exactly how much to risk on the next trade to reach your goal safely.</li>
              <li><strong>Hard Stops:</strong> If your loss limit is reached, it locks you out to prevent further damage.</li>
            </ul>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold uppercase flex items-center gap-2">
              <Zap className="h-6 w-6 text-primary" /> The Roadmap to Consistency
            </h2>
            <p>
              Consistency comes from repeating the same process over and over. By using the same session parameters every day, you train your brain to follow a routine. Over time, this routine becomes second nature, and your results will become more predictable.
            </p>
          </section>

          <Separator className="my-8" />

          <div className="bg-primary/5 p-8 rounded-2xl border border-primary/10 space-y-4 text-center">
            <h3 className="text-xl font-bold uppercase">Ready to Build a Better Trading Habit?</h3>
            <p className="text-sm text-muted-foreground">
              Start your first disciplined session today with our free Trade Advisor.
            </p>
            <div className="flex justify-center">
              <Button asChild className="font-bold uppercase h-12 px-8">
                <Link href="/">Start Trade Session</Link>
              </Button>
            </div>
          </div>
        </article>
      </main>

      <footer className="mt-12 border-t bg-muted/50 py-12">
        <div className="container mx-auto px-4 text-center">
          <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-2">tacalculator.com</p>
          <p className="text-xs text-muted-foreground">© {new Date().getFullYear()} Expert Financial Education.</p>
        </div>
      </footer>
    </div>
  );
}
