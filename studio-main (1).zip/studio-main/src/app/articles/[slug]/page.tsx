
'use client';

import Link from 'next/link';
import { useParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { ChevronLeft, BarChart3, BookOpen, Newspaper } from 'lucide-react';
import { ThemeToggle } from '@/components/theme-toggle';

const ARTICLES_DATA: Record<string, { title: string, content: string }> = {
  "binary-math": {
    title: "Binary Options Math: Beating Payouts",
    content: "Binary options platforms typically offer payouts between 70% and 90%. Mathematically, this creates a negative expectancy. To overcome this, traders must either have a win rate higher than 55% or use dynamic position sizing like the one found in our Trade Advisor. This article explores the probability models behind systematic binary trading and how to maintain a green account even with a 50% win rate."
  },
  "order-blocks": {
    title: "Institutional Order Blocks Guide",
    content: "Order blocks represent areas where institutional traders have placed significant orders. These often appear as the 'last candle' before a major impulsive move. When the market returns to these levels, it often finds 'liquidity' to continue the trend. Learning to identify valid order blocks from 'traps' is the key to trading with the Smart Money."
  },
  "liquidity-sweeps": {
    title: "Liquidity Sweeps Strategy",
    content: "Liquidity sweeps occur when the market purposefully moves past known support or resistance levels to trigger retail stop losses. Once this liquidity is grabbed, the institutional 'smart money' enters their true direction. We teach you how to spot these fake-outs and trade the reversal."
  },
  "fvg-secrets": {
    title: "Fair Value Gaps (FVG) Secrets",
    content: "A Fair Value Gap (FVG) is a market imbalance where price moves so fast that only one side of the market is filled. This creates a gap that the market usually returns to 'fill' later. FVGs are high-probability magnets for price action and can be used as entry points for trend continuations."
  },
  "revenge-trading": {
    title: "Trading Psychology: Stop Revenge Trading",
    content: "Revenge trading is the primary cause of account blowouts. After a loss, the human brain triggers a fight-or-flight response, leading to emotional, high-risk trades. Learn how to use a 'Session Plan' to create emotional boundaries and walk away from the screen when your limit is reached."
  },
  "risk-management": {
    title: "Advanced Risk Management 101",
    content: "Risk management is not just about having a stop loss; it's about position sizing relative to your account equity. We discuss the 1% rule, the 2% rule, and how volatility should dictate your lot size. Professional trading is a game of survival, and risk management is your shield."
  },
  "smc-intro": {
    title: "SMC: Smart Money Concepts",
    content: "Smart Money Concepts (SMC) focus on market structure, liquidity, and supply/demand zones. By understanding 'Break of Structure' (BOS) and 'Change of Character' (CHOCH), you can align your trades with the true institutional trend instead of chasing retail patterns."
  },
  "forex-scalping": {
    title: "Forex Scalping Mastery",
    content: "Scalping involves taking small profits from numerous trades throughout the day. Using 1-minute and 5-minute charts, we show how to use VWAP, Moving Averages, and institutional status to find high-conviction scalping opportunities."
  },
  "atr-volatility": {
    title: "Using ATR for Volatility",
    content: "The Average True Range (ATR) measures market noise. A static stop loss of 10 pips might work on a quiet day but will be hit instantly during high volatility. Learn how to adjust your stops dynamically using ATR to stay in the trade longer."
  },
  "compounding": {
    title: "The Power of Compounding",
    content: "Compounding is the 8th wonder of the world. By reinvesting profits and slowly increasing position sizes, even a $100 account can grow exponentially over months. We provide a step-by-step roadmap for systematic account growth."
  },
  "news-trading": {
    title: "News Trading Strategy",
    content: "High-impact news like NFP, CPI, and FOMC creates massive slippage and volatility. We explain the 'Straddle Strategy' and why most professional traders wait 15 minutes after the news release before entering a position."
  },
  "s-r-vs-s-d": {
    title: "Support/Resistance vs Supply/Demand",
    content: "While Support and Resistance are lines, Supply and Demand are zones. Zones provide a more realistic buffer for price action. This guide helps you distinguish between retail trendlines and true institutional accumulation zones."
  },
  "session-plan": {
    title: "Daily Session Planning",
    content: "A professional trader treats their day like a business. This includes pre-market analysis, setting daily profit/loss targets, and reviewing every trade at the end of the session. Success is built in the preparation."
  },
  "candlestick-secrets": {
    title: "Price Action Candlesticks",
    content: "Candlesticks are not just shapes; they represent the battle between buyers and sellers. Pin bars, engulfing patterns, and dojis tell a story of exhaustion or momentum. Learn to read the underlying pressure behind the price action."
  },
  "full-time-trading": {
    title: "The Road to Full-Time Trading",
    content: "Becoming a full-time trader requires more than just a good strategy; it requires capital, discipline, and a business mindset. We provide a realistic timeline and the milestones you need to achieve before quitting your day job."
  }
};

export default function ArticlePage() {
  const params = useParams();
  const slug = params.slug as string;
  const article = ARTICLES_DATA[slug] || { title: "Article Not Found", content: "Sorry, this educational guide is not available yet." };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b bg-background/95 backdrop-blur sticky top-0 z-50">
        <div className="container flex h-14 items-center justify-between px-4 max-w-2xl mx-auto">
          <Link href="/" className="text-sm font-black uppercase tracking-tighter hover:text-primary transition-colors flex items-center gap-1">
            <ChevronLeft className="h-4 w-4" /> All Tools
          </Link>
          <ThemeToggle />
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-2xl">
        <article className="space-y-8">
          <div className="space-y-4 text-center">
            <span className="text-[10px] font-bold uppercase tracking-widest text-primary px-3 py-1 bg-primary/5 rounded-full border border-primary/20">
              Trading Academy
            </span>
            <h1 className="text-4xl font-black uppercase tracking-tighter leading-none m-0">
              {article.title}
            </h1>
            <p className="text-muted-foreground text-sm italic">
              Empowering professional traders with mathematical precision.
            </p>
          </div>

          <p className="text-lg leading-relaxed font-medium whitespace-pre-wrap">
            {article.content}
          </p>

          <Separator className="my-8" />

          <div className="bg-primary/5 p-8 rounded-2xl border border-primary/10 space-y-4 text-center">
            <BarChart3 className="h-10 w-10 text-primary mx-auto" />
            <h3 className="text-xl font-bold uppercase">Ready to apply this logic?</h3>
            <p className="text-sm text-muted-foreground">
              Use our professional Trade Advisor to manage your session goals with mathematical precision.
            </p>
            <div className="flex justify-center">
              <Button asChild className="font-bold uppercase h-12 px-8 border-b-4 border-primary/50 rounded-xl">
                <Link href="/">Open Trade Advisor</Link>
              </Button>
            </div>
          </div>
        </article>
      </main>

      <footer className="mt-12 border-t bg-muted/50 py-12">
        <div className="container mx-auto px-4 text-center">
          <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest mb-2">tacalculator.com</p>
          <p className="text-xs text-muted-foreground">© {new Date().getFullYear()} Institutional Trading Education.</p>
        </div>
      </footer>
    </div>
  );
}
