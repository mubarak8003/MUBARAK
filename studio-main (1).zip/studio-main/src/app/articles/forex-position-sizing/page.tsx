
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { ChevronLeft, Calculator, TrendingUp, ShieldAlert } from 'lucide-react';

export const metadata = {
  title: 'How to Calculate Forex Position Size: A Complete Guide | tacalculator.com',
  description: 'Learn how to calculate forex lot sizes professionally to manage risk. Includes examples for EUR/USD, GBP/JPY, and more.',
};

export default function ForexPositionSizingArticle() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b bg-background/95 backdrop-blur sticky top-0 z-50">
        <div className="container flex h-14 items-center px-4 max-w-2xl mx-auto">
          <Link href="/articles" className="text-sm font-black uppercase tracking-tighter hover:text-primary transition-colors flex items-center gap-1">
            <ChevronLeft className="h-4 w-4" /> All Articles
          </Link>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-2xl">
        <article className="space-y-8 prose prose-neutral dark:prose-invert">
          <div className="space-y-4 text-center">
            <span className="text-[10px] font-bold uppercase tracking-widest text-primary px-3 py-1 bg-primary/5 rounded-full border border-primary/20">
              Forex Education
            </span>
            <h1 className="text-4xl font-black uppercase tracking-tighter leading-none m-0">
              How to Calculate Forex Position Size: A Complete Guide
            </h1>
            <p className="text-muted-foreground text-sm italic">
              Published on March 6, 2024 • 8 min read
            </p>
          </div>

          <p className="text-lg leading-relaxed">
            Forex position sizing is the most critical skill for long-term trading success. Many beginners focus on entry signals, but professional traders focus on <strong>how much</strong> to buy or sell. This guide will show you exactly how to calculate your lot size to ensure you never blow your account.
          </p>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold uppercase flex items-center gap-2">
              <Calculator className="h-6 w-6 text-primary" /> The Position Sizing Formula
            </h2>
            <p>
              To calculate your position size, you need three key pieces of information:
            </p>
            <ul className="list-disc pl-6 space-y-2">
              <li><strong>Risk Amount:</strong> How much money you are willing to lose in a single trade (e.g., 1% of your $10,000 account = $100).</li>
              <li><strong>Stop Loss in Pips:</strong> The distance from your entry point to your exit point if the trade goes wrong.</li>
              <li><strong>Pip Value:</strong> The value of one pip for the currency pair you are trading.</li>
            </ul>
            <div className="bg-muted p-6 rounded-xl border font-mono text-center space-y-2">
              <p className="text-xs text-muted-foreground uppercase">Lot Size Formula</p>
              <p className="text-xl font-bold">Position Size = (Risk Amount) / (Stop Loss in Pips * Pip Value)</p>
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold uppercase flex items-center gap-2">
              <TrendingUp className="h-6 w-6 text-primary" /> Why Position Sizing Matters
            </h2>
            <p>
              Without proper sizing, a single bad trade could wipe out weeks of profits. By using a consistent percentage risk (like 1% or 0.5% per trade), you ensure that no single trade can significantly damage your capital. This is the secret to <strong>trading longevity</strong>.
            </p>
            <p>
              Our <Link href="/" className="text-primary font-bold hover:underline">Forex Position Size Calculator</Link> automates this entire process for you, taking into account current market prices and account balances.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold uppercase flex items-center gap-2">
              <ShieldAlert className="h-6 w-6 text-primary" /> Common Mistakes
            </h2>
            <ul className="list-disc pl-6 space-y-2">
              <li><strong>Over-leveraging:</strong> Using too much lot size relative to your stop loss.</li>
              <li><strong>Inconsistent Risking:</strong> Risking $100 on one trade and $500 on the next.</li>
              <li><strong>Ignoring Pip Value:</strong> Forgetting that a pip on USD/JPY is valued differently than a pip on EUR/USD.</li>
            </ul>
          </section>

          <Separator className="my-8" />

          <div className="bg-primary/5 p-8 rounded-2xl border border-primary/10 space-y-4">
            <h3 className="text-xl font-bold uppercase text-center">Ready to Trade Professionally?</h3>
            <p className="text-sm text-muted-foreground text-center">
              Don't guess your lot sizes. Use our free tool to calculate them instantly and accurately.
            </p>
            <div className="flex justify-center">
              <Button asChild className="font-bold uppercase h-12 px-8">
                <Link href="/">Try the Forex Calculator</Link>
              </Button>
            </div>
          </div>
        </article>
      </main>

      <footer className="mt-12 border-t bg-muted/50 py-12">
        <div className="container mx-auto px-4 text-center">
          <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-2">tacalculator.com</p>
          <p className="text-xs text-muted-foreground">© {new Date().getFullYear()} Expert Financial Education.</p>
        </div>
      </footer>
    </div>
  );
}
