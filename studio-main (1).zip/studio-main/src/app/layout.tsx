
import type {Metadata} from 'next';
import './globals.css';
import { Toaster } from "@/components/ui/toaster"
import GoogleAnalytics from '@/components/GoogleAnalytics';
import Script from 'next/script';
import OfflineIndicator from '@/components/OfflineIndicator';
import { ThemeProvider } from '@/components/theme-provider';

export const metadata: Metadata = {
  title: 'Free Financial & Trading Calculators | tacalculator.com',
  description: 'A free suite of powerful financial calculators for traders. Includes a Trade Advisor for session goals, Stock Stop-Loss for risk management, Forex Position Sizing, a Percentage calculator, and a standard calculator to empower your trading decisions.',
  manifest: "/manifest.json",
  icons: {
    icon: "/favicon.ico",
  },
  viewport: 'width=device-width, initial-scale=1, maximum-scale=1',
  verification: {
    other: {
      'msvalidate.01': '9775FD3675F30756D2B88C178E6DA752',
    },
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="true" />
        <link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet" />
        <Script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3828575108248115" crossOrigin="anonymous" strategy="afterInteractive"></Script>
      </head>
      <body className="font-body antialiased">
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <GoogleAnalytics />
          <OfflineIndicator />
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
