# **App Name**: AI Next Trade Advisor

## Core Features:

- Trade Advisor: Provides advice to users for future trades.
- Profit Calculation: Calculate and keep a running tally of the cumulative profit to date.
- Loss Detection: Allow users to record the money lost during the previous trade
- Win Detection: Allow users to record the money gained during the previous trade
- AI-Powered Trade Amount Suggestion: Suggest the ideal trade amount after each trade (win or loss) by using an AI tool, targeting a 10% profit over 100 trades.

## Style Guidelines:

- Primary color: Strong blue (#29ABE2), suggesting intelligence and confidence.
- Background color: Light gray (#F5F5F5), providing a neutral backdrop.
- Accent color: Vibrant green (#90EE90), to indicate profit or success.
- Body and headline font: 'Inter', a sans-serif font for clear and objective readability.
- Use a series of clear, modern, geometric icons to denote winning or losing states and amounts. A simple upward arrow may represent profit, a downward arrow represents loss, and a line chart or progress bar can denote profit over time.
- Employ a simple card layout. Keep trade amounts large, clear, and readable to emphasize the critical info the user needs. Numbers must be able to be displayed clearly.
- Add subtle transitions to emphasize important feedback, such as the latest profit and loss amounts. As the user interacts with the trade buttons (won, lost) reinforce with an animation, such as growth or shrinking of the display number and the overall card. All transitions and animations should be unobtrusive.